"""
info_data_api.py — Unified API for static and semi-static data.

This module defines the :class:`InfoDataAPI`, a high-level interface for querying
reference or semi-static information (TER, FX composition, PCF, NAV, etc.) from multiple
data providers (Oracle, Bloomberg, Timescale). It complements the
:class:`MarketDataAPI` for dynamic data by focusing on descriptive, fundamental, and
slowly changing fields.

Responsibilities:
    - Manage Reference, Bulk, and Historical static requests
    - Normalize identifiers (ISIN, ticker, id) and parameters across sources
    - Handle provider-specific data aggregation and field mapping
    - Integrate with caching and autocomplete mechanisms
    - Expose convenience wrappers (e.g., get_ter, get_fx_composition, get_pcf_composition)

Typical workflow:
    >>> api = InfoDataAPI(client)
    >>> ter = api.get_ter(isin="IE00B4L5Y983")
    >>> fx = api.get_fx_composition(isin="IE00B4L5Y983", source="oracle")
    >>> pcf = api.get_pcf_composition(["IE00B4L5Y983", "IE00B1FZS350"], reference_date="yesterday")
"""

import logging
import uuid
from datetime import timedelta
from typing import Optional, Union, List, Dict

import pandas as pd
from dateutil.utils import today

from bshdata.core.decorators.respect_cache_status import respect_cache_kwarg
from bshdata.core.enums.fields import StaticField
from bshdata.core.holidays.holiday_manager import HolidayManager
from bshdata.core.requests.request_builder.request_builder import RequestBuilder
from bshdata.core.utils.common import normalize_list
from bshdata.core.utils.retry import RetryManager
from interface.api.base_api import BaseAPI


class InfoDataAPI(BaseAPI):
    """
    High-level API for static and semi-static data (TER, PCF, FX, anagraphic, ecc...).

    This class manages static-type requests such as Reference, Bulk, and Historical queries.
    It created Instrument and Requests (historical, bulk and reference) to be sent to central client.
    """

    # ============================================================
    # 1️⃣ DISPATCH INTERNO (semplificato)
    # ============================================================

    def _dispatch(
            self,
            instruments: list,
            fields: Union[str, List[str]],
            source: Union[str, List[str]],
            type: Union[str, List[str]],
            subscriptions: Optional[Union[str, List[str]]] = None,
            market: Optional[Union[str, List[str]]] = None,
            **kwargs,
    ):
        """
        Dispatch generico: costruisce e invia le Request in batch.
        """
        if not instruments:
            return None

        n = len(instruments)
        fields = [fields] if isinstance(fields, str) else fields
        market = normalize_list(market, n)
        source = normalize_list(source, n)
        subscriptions = normalize_list(subscriptions, n)

        # Determina il tipo di richiesta (Reference, Historical o Bulk)

        requests = []

        # Costruisce le singole Request
        for i, inst in enumerate(instruments):
            req = RequestBuilder.build_static_request(
                instrument=inst,
                fields=fields,
                market=market[i],
                source=source[i],
                subscriptions=subscriptions[i],
                type=type[i],
                **kwargs,
            )
            requests.append(req)

        batch_id = str(uuid.uuid4())
        print(f"[InfoDataAPI.dispatch] batch={batch_id} n={len(requests)}")

        # Invia al client e aggrega le risposte
        return self._aggregate(self.client.send(requests))


    # ============================================================
    # 3️⃣ ENTRY POINT PRINCIPALE
    # ============================================================
    @respect_cache_kwarg
    def get(
            self,
            type: str = None,
            id: Optional[Union[str, List[str]]] = None,
            isin: Optional[Union[str, List[str]]] = None,
            ticker: Optional[Union[str, List[str]]] = None,
            market: Optional[Union[str, List[str]]] = None,
            source: Optional[Union[str, List[str]]] = None,
            fields: Union[str, List[str]] = "MID",
            currency: Union[str, List[str]] = "EUR",
            subscriptions: Optional[Union[str, List[str], Dict[str, str]]] = None,
            autocomplete: Optional[bool] = None,
            fallbacks: Optional[List[Dict]] = None,
            **extra_params,
    ):
        """
        Retrieve static or semi-static data for one or more instruments.

        This unified entry point constructs and dispatches static requests
        (Reference, Bulk, or Historical) depending on parameters and data source.
        It automatically normalizes inputs, builds the appropriate instrument objects,
        and aggregates provider responses into a consistent format.

        Args:
            type (str, optional): Instrument type (e.g., 'ETP', 'FUTURE', 'STOCK').
            id (str | list[str] | None): Instrument identifiers (e.g., "IHYG", "RXZ4", "EURUSD").
                If missing, it is inferred from `isin` or `ticker`.
            isin (str | list[str] | None): Instrument ISIN code(s).
            ticker (str | list[str] | None): Instrument ticker(s).
            market (str | list[str], optional): Market(s) associated with the instruments (e.g., 'ETFP', 'EUREX').
            source (str | list[str], optional): Data source(s) such as 'oracle', 'bloomberg', or 'timescale'.
            fields (str | list[str]): Static fields to retrieve (e.g., 'TER', 'NAV', 'FX_COMPOSITION').
            currency (str | list[str]): Instrument currency or list of currencies. Defaults to 'EUR'.
            subscriptions (str | list[str] | dict[str, str], optional): Optional subscription identifiers.
            autocomplete (bool, optional): Whether to auto-complete missing metadata
                (e.g., infer ISIN from ticker using Oracle lookup).
            **extra_params: Additional provider- or instrument-specific parameters
                passed to the underlying request builder.

        Returns:
            dict | pd.DataFrame: Aggregated results per instrument, with standardized field names
            (field renaming handled automatically via `StaticField` mapping).

        Example:
            >>> api = InfoDataAPI(client)
            >>> result = api.get(
            ...     type="ETP",
            ...     isin=["IE00B4L5Y983", "IE00B1FZS350"],
            ...     source="oracle",
            ...     fields=["TER", "FX_COMPOSITION"]
            ... )
            >>> print(result["IE00B4L5Y983"]["TER"])
        """

        #todo: aggiungi la possibilita di aggiungere parametri come dict la cui chiave è id.

        auto = self.autocomplete if autocomplete is None else autocomplete

        ids, isins, tickers = self._resolve_identifiers(id, isin, ticker, autocomplete=auto)
        n = len(ids)

        # Normalizza
        currency = normalize_list(currency, n)
        market = normalize_list(market, n)
        source = normalize_list(source, n)
        type = normalize_list(type, n)
        subscriptions = normalize_list(subscriptions, n)

        if any(x is not None for x in ids + isins + tickers):
            instruments = [
                self._build_instrument(
                    id=ids[i],
                    type=type[i],
                    ticker=tickers[i],
                    isin=isins[i],
                    currency=currency[i],
                    market=market[i],
                    autocomplete=auto,
                    **extra_params
                )
                for i in range(n)
            ]
        else:
            instruments = [None]*n

        dispatch_params = dict(
            instruments=instruments,
            fields=fields,
            source=source,
            subscriptions=subscriptions,
            market=market,
            type=type,
            **extra_params,
        )

        # Dispatch
        result = self._dispatch(**dispatch_params)

        result = self._rename_fields(result, fields if isinstance(fields, list) else [fields], source)

        if not fallbacks:
            return result
        # Retry con fallback
        if isinstance(fallbacks, dict):
            fallbacks = [fallbacks]

        result = RetryManager.retry_info(
            dispatch=self._dispatch,
            result=result,
            params=dispatch_params,
            fallbacks=fallbacks
        )

        return self._rename_fields(result, fields if isinstance(fields, list) else [fields], source)

    def _rename_fields(self, result, fields, source):
        """
        Rinomina i campi in base alla mappatura StaticField.
        Supporta sia:
          - dict[str, dict[str, Any]]  → ritorna dict
          - pd.DataFrame con MultiIndex (instrument, field) → ritorna DataFrame
        """
        try:
            # Crea mappatura Bloomberg → interno
            mapping = {
                StaticField.from_str(f, source).upper(): f for f in fields
            }

            # ------------------------------------------------------------
            # Caso: DataFrame
            # ------------------------------------------------------------
            if isinstance(result, pd.DataFrame):
                if isinstance(result.columns, pd.MultiIndex) and "field" in result.columns.names:
                    # livello "field" esplicito nel MultiIndex
                    new_fields = [
                        mapping.get(field.upper(), field)
                        for _, field in result.columns
                    ]
                    result.columns = pd.MultiIndex.from_tuples(
                        [(instr, new_field) for (instr, _), new_field in zip(result.columns, new_fields)],
                        names=result.columns.names,
                    )
                else:
                    # singolo livello colonne → rinomina direttamente
                    result.columns = [
                        mapping.get(c.upper(), c) for c in result.columns
                    ]
                return result

            # ------------------------------------------------------------
            # Caso: dict
            # ------------------------------------------------------------
            renamed = {}
            if isinstance(result, pd.Series):
                return result.rename(mapping)

            for instr, fields_dict in result.items():
                if not isinstance(fields_dict, dict):
                    renamed[instr] = fields_dict
                    continue
                renamed[instr] = {
                    mapping.get(field.upper(), field): value
                    for field, value in fields_dict.items()
                }

            return renamed

        except Exception as e:
            logging.warning("Failed to rename fields: %s", e)
            return result

    # ============================================================
    # 4️⃣ WRAPPERS UTILI
    # ============================================================

    def get_ter(self, id=None, isin=None, ticker=None, source="bloomberg", **kwargs):
        """Restituisce il TER (Total Expense Ratio) degli ETF."""
        return self.get(type="ETP", id=id, isin=isin, ticker=ticker, source=source, fields="TER",
                        request_type="reference", **kwargs)

    def get_dividends(self, isin=None, id=None, ticker=None,
                      start=today() - timedelta(days=360),
                      end=today(), source="bloomberg", type="ETP"):
        """Restituisce i dividendi storici."""
        return self.get(type=type, id=id, isin=isin, ticker=ticker, source=source, fields="DIVIDEND",
                        request_type="bulk", start=start, end=end)

    def get_fx_composition(self, isin=None, ticker=None, id=None, reference_date=None,
                           fx_fxfwrd="both", source="oracle", **kwargs):
        """Restituisce la composizione valutaria (FX composition)."""
        if fx_fxfwrd.lower() not in ["both", "fx", "fxfwrd"]:
            raise ValueError("Invalid fx_fxfwrd param")
        return self.get(type="ETP", id=id, isin=isin, ticker=ticker, source=source, fields="FX_COMPOSITION",
                        request_type="bulk", reference_date=reference_date, fx_fxfwrd=fx_fxfwrd,**kwargs).T

    def get_pcf_composition(self, isins, reference_date=None, source="oracle", include_cash=False,
                            comp_field="WEIGHT_NAV"):
        if isinstance(reference_date, str):
            ref = reference_date.lower()
            if ref == "yesterday":
                reference_date = HolidayManager().previous_business_day(today())
            elif ref == "last":
                reference_date = None
        if comp_field.upper() not in ["WEIGHT_NAV", "N_INSTRUMENTS", "WEIGHT_RISK", "RAW"]:
            raise ValueError("Invalid comp_field")

        raw = self.get("ETP", isins, source=source, fields="PCF_COMPOSITION",
                       request_type="bulk", reference_date=reference_date, include_cash=include_cash)

        if isinstance(isins, str): isins = [isins]
        if comp_field.upper() == "RAW":
            return raw
        else:
            return raw.pivot_table(index="BSH_ID_ETF",
                                columns="BSH_ID_COMP",
                                values=comp_field.upper(),
                                aggfunc="first")

    def get_etp_fields(
            self,
            fields: Union[str, List[str]],
            type: str = "ETP",
            id: Optional[Union[str, List[str]]] = None,
            isin: Optional[Union[str, List[str]]] = None,
            ticker: Optional[Union[str, List[str]]] = None,
            market: Optional[Union[str, List[str]]] = None,
            source: Optional[Union[str, List[str]]] = "oracle",
            currency: Union[str, List[str]] = "EUR",
            subscriptions: Optional[Union[str, List[str], Dict[str, str]]] = None,
            autocomplete: Optional[bool] = None,
            **extra_params,
    ):

        return self.get(type, id, isin, ticker, market, source, fields, currency, subscriptions, autocomplete,
                        **extra_params)

    def get_nav(self, start, id=None, ticker=None, isin=None, subscriptions=None, source="bloomberg", end=today()):
        return self.get(type="ETP", id=id, isin=isin, ticker=ticker, source=source, fields="NAV",
                        subscriptions=subscriptions, start=start, end=end, request_type="historical")

    def get_future_fields(
            self,
            fields: Union[str, List[str]],
            type: str = "FUTURE",
            id: Optional[Union[str, List[str]]] = None,
            isin: Optional[Union[str, List[str]]] = None,
            ticker: Optional[Union[str, List[str]]] = None,
            market: Optional[Union[str, List[str]]] = None,
            source: Optional[Union[str, List[str]]] = "oracle",
            currency: Union[str, List[str]] = "EUR",
            subscriptions: Optional[Union[str, List[str], Dict[str, str]]] = None,
            autocomplete: Optional[bool] = None,
            **extra_params,
    ):
        """
        root, is_active_form,
        future_currency, future_underlying,
        suffix, timescale_root  kwargs
        """

        return self.get(type, id, isin, ticker, market, source, fields, currency, subscriptions, autocomplete,
                        **extra_params)

    def get_stock_fields(
            self,
            fields: Union[str, List[str]],
            ticker: Optional[Union[str, List[str]]] = None,
            id: Optional[Union[str, List[str]]] = None,
            isin: Optional[Union[str, List[str]]] = None,
            market: Optional[Union[str, List[str]]] = None,
            source: Optional[Union[str, List[str]]] = "oracle",
            currency: Union[str, List[str]] = None,
            subscriptions: Optional[Union[str, List[str]]] = None,
            **kwargs
    ):
        return self.get("STOCK", id, isin, ticker, market, source, fields,
                        currency, subscriptions, **kwargs)

    def get_stock_markets(
            self,
            ticker: Optional[Union[str, List[str]]] = None,
            id: Optional[Union[str, List[str]]] = None,
            isin: Optional[Union[str, List[str]]] = None,
            source: Optional[Union[str, List[str]]] = "oracle",
            currency: Union[str, List[str]] = None,
            **kwargs
    ):
        results = self.get("STOCK", id, isin, ticker,None, source, "STOCK_MARKETS_INFO",
                        currency, **kwargs)

        return results.drop("ISIN", axis=1, errors="ignore")