"""
ReturnAdjuster - Classe principale per calcolo ritorni aggiustati.

Orchestrazione del sistema Analytics:
1. Riceve Instrument già creati (da BshDataProvider)
2. Crea Analytics Classes (StockClass, ETFClass, etc.)
3. Scarica dati
4. Calcola aggiustamenti e correzioni FX
5. Pulisce ritorni
"""
from typing import List, Dict, Optional, Union
import pandas as pd
import datetime as dt

from bshdata.analytics.adjustments.base_instrument_class import PipelineClassFactory
from bshdata.analytics.adjustments.base_instrument_class.base_instrument import BaseInstrumentClass
from bshdata.client import BSHDataClient
from bshdata.core.instruments.instruments import Instrument
from bshdata.core.enums.instrument_types import InstrumentType
from bshdata.analytics.logger import AnalyticsLogger
from bshdata.analytics.adjustments.downloaders import ProviderAdapter
from bshdata.analytics.adjustments.utils import get_contiguous_date


class ReturnAdjuster:
    """
    Classe principale per calcolo ritorni aggiustati.

    Workflow tipico:
        >>> from bshdata.core.instruments.instrument_factory import InstrumentFactory
        >>>
        >>> # 1. Crea Instrument
        >>> factory = InstrumentFactory()
        >>> instruments = [
        ...     factory.create(type='ETP', isin='IE00B66F4759', currency='EUR'),
        ...     factory.create(type='ETP', isin='IE00B4PY7Y77', currency='USD')
        ... ]
        >>>
        >>> # 2. Crea ReturnAdjuster
        >>> adjuster = ReturnAdjuster(
        ...     instruments=instruments,
        ...     window_days=30,
        ...     last_day=dt.date.today()
        ... )
        >>>
        >>> # 3. Download e calcola
        >>> adjuster.set_data_downloader(bsh_client)
        >>> adjuster.download_data()
        >>> cleaned_returns = adjuster.clean_returns(returns_df)
    """

    def __init__(self,
                 instruments: Union[List[Instrument], List[str]],
                 relevant_dates: Optional[List[dt.date]] = None,
                 window_days: Optional[int] = None,
                 last_day: Optional[dt.date] = None,
                 backdating: bool = False,
                 fairvalue_time: Optional[dt.time] = None,
                 etf_coverage_threshold: Optional[float] = None,
                 allow_logging: bool = True,
                 default_currency: str = 'EUR',
                 default_instrument_type: str = 'STOCK'):
        """
        Inizializza ReturnAdjuster.

        Args:
            instruments: Lista di Instrument già creati O lista di ISIN (str)
            relevant_dates: Date esplicite (alternativa a window_days + last_day)
            window_days: Numero di giorni finestra (richiede last_day)
            last_day: Ultimo giorno della finestra (richiede window_days)
            backdating: Se True, date si riferiscono a "day from" invece di "day to"
            fairvalue_time: Ora per fairvalues intraday (default 17:15:00)
            etf_coverage_threshold: Soglia coverage per ETF FX (default 0.3)
            allow_logging: Abilita logging
            default_currency: Valuta default se instruments è lista ISIN (default 'EUR')
            default_instrument_type: Tipo default se instruments è lista ISIN (default 'STOCK')

        Raises:
            ValueError: Se parametri date non validi
        """
        # Validazione date
        if relevant_dates is not None and (window_days is not None or last_day is not None):
            raise ValueError("Provide either relevant_dates OR (window_days + last_day), not both.")
        if relevant_dates is None and (window_days is None or last_day is None):
            raise ValueError("If relevant_dates not provided, both window_days and last_day required.")

        # Setup date
        if relevant_dates is not None:
            self._check_dates(relevant_dates)
            self._relevant_dates: List[dt.date] = relevant_dates
        else:
            relevant_dates = self._generate_relevant_dates(window_days, last_day)
            self._relevant_dates = relevant_dates

        # Backdating logic
        self._backdating = backdating
        self._relevant_dates_mapping = {d: d for d in relevant_dates}

        if self._backdating:
            self._relevant_dates = relevant_dates[1:] + [get_contiguous_date(relevant_dates[-1], 1)]
            self._relevant_dates_mapping = {
                date_mapped: date_mapped_to
                for date_mapped, date_mapped_to in zip(self._relevant_dates, relevant_dates)
            }
            if self._relevant_dates[-1] > dt.date.today():
                raise ValueError("Backdating not supported when last date is today.")

        # Setup logger
        self._logger = AnalyticsLogger(
            log_terminal=allow_logging,
            log_terminal_level='INFO'
        )

        # Gestione Instrument vs ISIN
        if instruments and isinstance(instruments[0], str):
            # Sono ISIN - crea Instrument base
            self._logger.info("Creating Instrument objects from ISIN list...")
            from bshdata.core.instruments.instrument_factory import InstrumentFactory as BshFactory

            factory = BshFactory()
            self._instruments: List[Instrument] = []

            for id in instruments:
                inst = factory.create(
                    type=default_instrument_type,
                    id=id,
                    currency=default_currency
                )
                self._instruments.append(inst)

            self._logger.info(f"Created {len(self._instruments)} Instrument objects")
        else:
            # Sono già Instrument
            self._instruments: List[Instrument] = instruments
            self._logger.info(f"Using {len(self._instruments)} pre-created Instrument objects")

        # Estrai ISIN list
        self._isin_list: List[str] = [inst.isin for inst in self._instruments]

        # Parametri base
        self._fairvalues_df: Optional[pd.DataFrame] = None

        # Parametri ETF
        if etf_coverage_threshold is not None:
            assert 0 <= etf_coverage_threshold <= 1, (
                f"ETF coverage threshold must be in [0,1], got {etf_coverage_threshold}"
            )
        self._etf_coverage_threshold: float = etf_coverage_threshold or 0.3

        # Parametri FX e timing
        if fairvalue_time is not None:
            assert isinstance(fairvalue_time, dt.time), (
                f"fairvalue_time must be dt.time, got {type(fairvalue_time)}"
            )
        self._fairvalue_time: dt.time = fairvalue_time or dt.time(17, 15, 0)

        # Settlement e currency (estratti dagli Instrument)
        self._settlement_type: pd.Series = self._get_default_settlement()
        self._trading_currency: pd.Series = pd.Series(
            [str(inst.currency) for inst in self._instruments],
            index=self._isin_list
        )

        # Hard coding e mapping DataFrames
        self._bbg_codes_hard_coding_df: Optional[pd.DataFrame] = None
        self._ytm_mapping_df: Optional[pd.DataFrame] = None
        self._fx_mapping_df: Optional[pd.DataFrame] = None
        self._ter_hard_coding_df: Optional[pd.DataFrame] = None
        self._repo_hard_coding_df: Optional[pd.DataFrame] = None
        self._instrument_fx_weights: pd.DataFrame = pd.DataFrame()

        # Factory
        self._analytics_factory = PipelineClassFactory()

        # Provider adapter
        self._provider_adapter: Optional[ProviderAdapter] = None

        # Collections
        self._analytics_classes: Dict[InstrumentType, BaseInstrumentClass] = {}

        # Risultati
        self._adjustments_df: pd.DataFrame = pd.DataFrame()
        self._fx_corrections_df: pd.DataFrame = pd.DataFrame()
        self._adjustments_calculated: bool = False
        self._fx_corrections_calculated: bool = False

    # ========================================================================
    # SETUP METHODS
    # ========================================================================

    def set_data_downloader(self, bsh_client: BSHDataClient):
        """
        Configura il data downloader con client BshData.

        Args:
            bsh_client: Istanza di BSHDataClient configurato
        """
        self._provider_adapter = ProviderAdapter(
            bsh_client,
            bbg_code_hard_coded_df=self._bbg_codes_hard_coding_df,
            ytm_mapping_df=self._ytm_mapping_df,
            fx_mapping_df=self._fx_mapping_df,
            ter_hard_coding_df=self._ter_hard_coding_df,
            repo_hard_coding_df=self._repo_hard_coding_df
        )
        self._logger.info("ProviderAdapter configured")

    def set_fairvalues(self, fairvalues_df: pd.DataFrame):
        """Imposta fairvalues pre-caricati."""
        self._fairvalues_df = fairvalues_df

    def set_fairvalue_time(self, fairvalue_time: dt.time):
        """Imposta ora per fairvalues intraday."""
        self._fairvalue_time = fairvalue_time

    def set_bbg_code_hard_coding(self, bbg_code_hard_coding_df: pd.DataFrame):
        """
        Imposta override per BBG codes.

        Args:
            bbg_code_hard_coding_df: DataFrame(index=ISIN, columns=['BBG_CODE'])
        """
        self._bbg_codes_hard_coding_df = self._check_hard_coding(
            bbg_code_hard_coding_df, 'BBG_CODE', do_mapping_check=False
        )
        if self._provider_adapter is not None:
            self._provider_adapter._bbg_code_hard_coded_df = self._bbg_codes_hard_coding_df

    def set_ter_hard_coding(self, ter_hard_coding_df: pd.DataFrame):
        """
        Imposta override per TER.

        Args:
            ter_hard_coding_df: DataFrame(index=ISIN, columns=['TER'])
        """
        self._ter_hard_coding_df = self._check_hard_coding(
            ter_hard_coding_df, 'TER', do_mapping_check=False
        )
        if self._provider_adapter is not None:
            self._provider_adapter._ter_hard_coding_df = self._ter_hard_coding_df

    def set_ytm_mapping(self, ytm_mapping_df: pd.DataFrame):
        """
        Imposta mapping YTM (source -> target).

        Args:
            ytm_mapping_df: DataFrame(index=source_isin, columns=[target_isin])
        """
        self._ytm_mapping_df = self._check_hard_coding(
            ytm_mapping_df, 'YTM_MAPPING', do_column_check=False
        )
        if self._provider_adapter is not None:
            self._provider_adapter._ytm_mapping_df = self._ytm_mapping_df

    def set_fx_mapping(self, fx_mapping_df: pd.DataFrame):
        """
        Imposta mapping FX composition (source -> target).

        Args:
            fx_mapping_df: DataFrame(index=source_isin, columns=[target_isin])
        """
        self._fx_mapping_df = self._check_hard_coding(
            fx_mapping_df, 'FX_MAPPING', do_column_check=False
        )
        if self._provider_adapter is not None:
            self._provider_adapter._fx_mapping_df = self._fx_mapping_df

    def set_repo_hard_coding_for_instrument(self, repo_hard_coding_df: pd.DataFrame):
        """
        Imposta override per repo rates per strumento.

        Args:
            repo_hard_coding_df: DataFrame(index=ISIN, columns=['Repo'])
        """
        self._repo_hard_coding_df = self._check_hard_coding(
            repo_hard_coding_df, 'Repo', do_mapping_check=False
        )
        if self._provider_adapter is not None:
            self._provider_adapter._repo_hard_coding_df = self._repo_hard_coding_df

    def set_etf_coverage_threshold(self, etf_coverage_threshold: float):
        """Imposta soglia coverage per ETF."""
        assert 0 <= etf_coverage_threshold <= 1
        self._etf_coverage_threshold = etf_coverage_threshold

    def set_instrument_fx_weights(self, fx_weights: pd.DataFrame):
        """
        Imposta pesi FX per ETF.

        Args:
            fx_weights: DataFrame(index=ISIN, columns=['CURRENCY', 'WEIGHT', 'WEIGHT_FX_FORWARD'])
        """
        if fx_weights.empty:
            raise ValueError('FX weights DataFrame is empty')

        expected_cols = ['CURRENCY', 'WEIGHT', 'WEIGHT_FX_FORWARD']
        if len(fx_weights.columns) != 3:
            raise ValueError(f"Expected 3 columns: {expected_cols}, got {len(fx_weights.columns)}")

        if set(fx_weights.columns) != set(expected_cols):
            raise ValueError(f"Expected columns {expected_cols}, got {list(fx_weights.columns)}")

        missing_isins = [isin for isin in fx_weights.index if isin not in self._isin_list]
        if missing_isins:
            raise ValueError(f"ISINs in fx_weights not in isin_list: {missing_isins}")

        fx_weights[['WEIGHT', 'WEIGHT_FX_FORWARD']] = fx_weights[['WEIGHT', 'WEIGHT_FX_FORWARD']].astype(float)
        self._instrument_fx_weights = fx_weights

    def set_settlement_type(self, settlement_type_series: pd.Series):
        """
        Imposta tipo settlement per ISIN.

        Args:
            settlement_type_series: Series(index=ISIN, values='T+1' or 'T+2')
        """
        implemented_types = ['T+1', 'T+2']
        invalid_types = [t for t in settlement_type_series.unique() if t not in implemented_types]
        if invalid_types:
            raise ValueError(
                f"Invalid settlement types: {invalid_types}. "
                f"Implemented: {implemented_types}"
            )
        self._settlement_type.update(settlement_type_series)

    def set_trading_currency(self, trading_currency_series: pd.Series):
        """
        Imposta valuta di trading per ISIN.

        Args:
            trading_currency_series: Series(index=ISIN, values=currency code)
        """
        self._trading_currency.update(trading_currency_series)

    # ========================================================================
    # WORKFLOW PRINCIPALE
    # ========================================================================

    def download_data(self):
        """
        Scarica tutti i dati necessari.

        Workflow:
        1. Crea Analytics Classes (raggruppa Instrument per tipo)
        2. Scarica dati per ogni classe
        """
        if self._provider_adapter is None:
            raise RuntimeError("Call set_data_downloader(bsh_client) first")

        self._logger.info("="*60)
        self._logger.info("Starting data download")
        self._logger.info("="*60)

        # Mostra summary degli Instrument
        type_counts = {}
        for inst in self._instruments:
            t = str(inst.type)
            type_counts[t] = type_counts.get(t, 0) + 1

        self._logger.info(f"Processing {len(self._instruments)} instruments: {type_counts}")

        # Crea Analytics Classes (raggruppa per tipo)
        self._logger.info("Creating Analytics Classes...")
        self._analytics_classes = self._analytics_factory.create_pipeline_class(instrument_list=self._instruments,
                                                                                data_downloader=self._provider_adapter,
                                                                                relevant_dates=self._relevant_dates,
                                                                                settlement_type=self._settlement_type,
                                                                                logger=self._logger,
                                                                                etf_coverage_threshold=self._etf_coverage_threshold)

        self._logger.info(f"Created {len(self._analytics_classes)} Analytics Classes")

        # Download dati per ogni classe
        self._logger.info("Downloading data for each instrument class...")
        for instrument_type, analytics_class in self._analytics_classes.items():
            self._logger.info(f"Downloading data for {instrument_type}...")
            analytics_class.download_data()

        self._logger.info("="*60)
        self._logger.info("Data download complete!")
        self._logger.info("="*60)

    def get_adjustments(self, cumulative: bool = False) -> pd.DataFrame:
        """
        Calcola e restituisce aggiustamenti.

        Args:
            cumulative: Se True, calcola aggiustamenti cumulativi

        Returns:
            DataFrame con aggiustamenti (index=date, columns=ISIN)
        """
        if not self._adjustments_calculated:
            self._calculate_adjustments()

        if cumulative:
            adjustments_df = self._adjustments_df[::-1].cumsum()[::-1]
        else:
            adjustments_df = self._adjustments_df

        return adjustments_df.rename(index=self._relevant_dates_mapping)

    def get_fx_corrections(self,
                          fx_update: Optional[pd.Series] = None,
                          cumulative: bool = False) -> pd.DataFrame:
        """
        Calcola e restituisce correzioni FX.

        Args:
            fx_update: Serie con nuovi spot FX (opzionale, per aggiornamento)
            cumulative: Se True, calcola correzioni cumulative

        Returns:
            DataFrame con correzioni FX (index=date, columns=ISIN)
        """
        # Se c'è update FX, notifica gli strumenti
        if fx_update is not None:
            for analytics_class in self._analytics_classes.values():
                analytics_class.on_fx_update(fx_update)
            self._fx_corrections_calculated = False

        if not self._fx_corrections_calculated:
            self._calculate_fx_corrections()

        if cumulative:
            fx_corrections = self._fx_corrections_df[::-1].cumsum()[::-1]
        else:
            fx_corrections = self._fx_corrections_df

        return fx_corrections.rename(index=self._relevant_dates_mapping)

    def clean_returns(self, returns_df: pd.DataFrame, cumulative: bool = False) -> pd.DataFrame:
        """
        Pulisce ritorni applicando aggiustamenti e correzioni FX.

        Args:
            returns_df: DataFrame con ritorni da pulire (index=date, columns=ISIN)
            cumulative: Se True, applica correzioni cumulative

        Returns:
            DataFrame con ritorni puliti
        """
        self._check_df(returns_df)

        # Calcola correzioni se necessario
        if not self._adjustments_calculated:
            self._calculate_adjustments()
        if not self._fx_corrections_calculated:
            self._calculate_fx_corrections()

        # Applica correzioni per ogni classe
        cleaned_returns_df = pd.DataFrame()

        for analytics_class in self._analytics_classes.values():
            cleaned = analytics_class.clean_returns(returns_df, cumulative)
            cleaned_returns_df = pd.concat([cleaned_returns_df, cleaned], axis=1)

        return cleaned_returns_df.rename(index=self._relevant_dates_mapping)

    def get_returns_cleaned(self, fairvalues_df: pd.DataFrame, cumulative: bool = False) -> pd.DataFrame:
        """
        Calcola ritorni da fairvalues e li pulisce.

        Args:
            fairvalues_df: DataFrame con fairvalues (index=date, columns=ISIN)
            cumulative: Se True, calcola ritorni cumulativi

        Returns:
            DataFrame con ritorni puliti
        """
        returns_df = fairvalues_df.pct_change().dropna()
        self._check_df(returns_df)

        if cumulative:
            returns_df = (1 + returns_df).cumprod() - 1

        return self.clean_returns(returns_df, cumulative)

    # ========================================================================
    # METODI PRIVATI - Calcoli
    # ========================================================================

    def _calculate_adjustments(self):
        """Calcola aggiustamenti per tutti gli strumenti."""
        self._logger.info("Calculating adjustments...")

        self._adjustments_df = pd.DataFrame()
        for analytics_class in self._analytics_classes.values():
            adjustments = analytics_class.get_adjustments()
            self._adjustments_df = pd.concat([self._adjustments_df, adjustments], axis=1)

        self._adjustments_calculated = True
        self._logger.info(f"Adjustments calculated: shape {self._adjustments_df.shape}")

    def _calculate_fx_corrections(self):
        """Calcola correzioni FX per tutti gli strumenti."""
        self._logger.info("Calculating FX corrections...")

        self._fx_corrections_df = pd.DataFrame()
        for analytics_class in self._analytics_classes.values():
            fx_corrections = analytics_class.get_fx_corrections()
            self._fx_corrections_df = pd.concat([self._fx_corrections_df, fx_corrections], axis=1)

        self._fx_corrections_calculated = True
        self._logger.info(f"FX corrections calculated: shape {self._fx_corrections_df.shape}")

    def _get_default_settlement(self) -> pd.Series:
        """
        Determina settlement type default basato su tipo strumento.

        Returns:
            Series(index=ISIN, values='T+1' or 'T+2')
        """
        settlement = {}

        for inst in self._instruments:
            # Future tipicamente T+1, tutto il resto T+2
            if inst.type == InstrumentType.FUTURE:
                settlement[inst.isin] = 'T+1'
            else:
                settlement[inst.isin] = 'T+2'

        return pd.Series(settlement, index=self._isin_list)

    # ========================================================================
    # METODI PRIVATI - Validazione
    # ========================================================================

    def _check_hard_coding(self,
                          df: pd.DataFrame,
                          name: str,
                          do_index_check: bool = True,
                          do_mapping_check: bool = True,
                          do_column_check: bool = True) -> pd.DataFrame:
        """Valida DataFrame di hard coding/mapping."""
        if df.empty:
            raise ValueError(f"{name} DataFrame is empty")

        if len(df.columns) != 1:
            raise ValueError(f"{name} must have exactly 1 column, got {len(df.columns)}")

        if do_index_check:
            missing_isins = [isin for isin in df.index if isin not in self._isin_list]
            if missing_isins:
                raise ValueError(f"{name}: ISINs not in isin_list: {missing_isins}")

        if do_mapping_check:
            mapped_isins = df.iloc[:, 0].tolist()
            invalid_isins = [isin for isin in mapped_isins if isin not in self._isin_list]
            if invalid_isins:
                raise ValueError(f"{name}: Mapped ISINs not in isin_list: {invalid_isins}")

        if do_column_check:
            if df.columns[0] != name:
                raise ValueError(f"{name}: Column name should be '{name}', got '{df.columns[0]}'")

        return df

    def _check_df(self, df: pd.DataFrame):
        """Verifica che le date del DataFrame corrispondano a relevant_dates."""
        extra_dates = [day for day in df.index if day not in self._relevant_dates]
        if extra_dates:
            raise ValueError(
                f"DataFrame contains dates not in relevant_dates: {extra_dates}"
            )

    @staticmethod
    def _check_dates(relevant_dates: List[dt.date]):
        """Valida lista di date."""
        for elem in relevant_dates:
            if not isinstance(elem, dt.date):
                raise TypeError(f"Element {elem} is not a date")

        if relevant_dates != sorted(relevant_dates):
            raise ValueError("Dates must be sorted")

    @staticmethod
    def _generate_relevant_dates(window_days: int, last_day: dt.date) -> List[dt.date]:
        """Genera lista di date da window_days e last_day."""
        relevant_dates = []
        for i in range(window_days + 1):
            day = get_contiguous_date(last_day, -i)
            relevant_dates.append(day)
        return list(reversed(relevant_dates))