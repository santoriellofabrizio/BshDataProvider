"""
Logger per il modulo Analytics del progetto BshDataProvider.
Adattato da ReturnAdjusterLogger per l'integrazione nel progetto esistente.
"""
import logging
from typing import Any, Optional


class AnalyticsLogger:
    """Logger specializzato per operazioni di analytics e calcolo ritorni."""

    _file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    def __init__(self, log_terminal: bool = True, log_terminal_level: str = 'INFO'):
        """
        Inizializza il logger per analytics.

        Args:
            log_terminal: Se True, abilita il logging su terminale
            log_terminal_level: Livello di logging ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL')
        """
        self._logger = logging.getLogger('BshData.Analytics')

        # Create handlers
        terminal_handler = logging.StreamHandler()

        # Map log levels
        self._log_terminal_level = self._string_to_log_level(log_terminal_level)
        terminal_handler.setLevel(self._log_terminal_level)

        # Create formatters and add it to handlers
        terminal_handler.setFormatter(CustomFormatter())

        # Add handlers to the logger (avoid duplicates)
        if not self._logger.handlers:
            if log_terminal:
                self._logger.addHandler(terminal_handler)

        # Set logger level
        if log_terminal:
            self._logger.setLevel(logging.DEBUG)
        else:
            self._logger.setLevel(logging.CRITICAL + 1)

        self._logger.propagate = False

    def info(self, msg: str, method_caller: Optional[Any] = None):
        """Log info message with optional caller context."""
        class_name = f'{type(method_caller).__name__} - ' if method_caller is not None else ''
        self._logger.info(f'{class_name}{msg}')

    def debug(self, msg: str, method_caller: Optional[Any] = None):
        """Log debug message with optional caller context."""
        class_name = f'{type(method_caller).__name__} - ' if method_caller is not None else ''
        self._logger.debug(f'{class_name}{msg}')

    def warning(self, msg: str, method_caller: Optional[Any] = None):
        """Log warning message with optional caller context."""
        class_name = f'{type(method_caller).__name__} - ' if method_caller is not None else ''
        self._logger.warning(f'{class_name}{msg}')

    def error(self, msg: str, method_caller: Optional[Any] = None):
        """Log error message with optional caller context."""
        class_name = f'{type(method_caller).__name__} - ' if method_caller is not None else ''
        self._logger.error(f'{class_name}{msg}')

    def critical(self, msg: str, method_caller: Optional[Any] = None):
        """Log critical message with optional caller context."""
        class_name = f'{type(method_caller).__name__} - ' if method_caller is not None else ''
        self._logger.critical(f'{class_name}{msg}')

    @staticmethod
    def _string_to_log_level(log_terminal_level: str) -> int:
        """Convert string log level to logging constant."""
        level_mapping = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR,
            'CRITICAL': logging.CRITICAL
        }
        return level_mapping.get(log_terminal_level.upper(), logging.INFO)


class CustomFormatter(logging.Formatter):
    """Custom formatter with colors for different log levels."""

    COLORS = {
        'DEBUG': '\033[92m',  # green
        'INFO': '\033[97m',  # white
        'WARNING': '\033[93m',  # yellow
        'ERROR': '\033[91m',  # red
        'CRITICAL': '\033[1;91m',  # bold red
        'RESET': '\033[0m'  # color reset
    }

    def format(self, record):
        """Format log record with color."""
        color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        reset = self.COLORS['RESET']
        base_format = '%(asctime)s - %(message)s'
        formatter = logging.Formatter(base_format)
        message = formatter.format(record)
        return f"{color}{message}{reset}"