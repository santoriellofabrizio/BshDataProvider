"""
Adapter che collega il modulo Analytics ai provider esistenti di BshDataProvider.
Mantiene logiche di mapping e hard coding, delega download alle API esistenti.
"""
import datetime as dt
import logging
from typing import List, Optional, Dict
import pandas as pd

from bshdata.core.enums.instrument_types import InstrumentType
from bshdata.core.holidays.holiday_manager import HolidayManager
from interface.api.info_data_api import InfoDataAPI
from interface.api.market_api import MarketDataAPI

logger = logging.getLogger(__name__)


class ProviderAdapter:
    """
    Adapter per connettere il modulo analytics ai provider BshData.

    Responsabilità:
    - Interfaccia semplificata per scaricare dati
    - Gestione mapping (YTM, FX)
    - Gestione hard coding overrides (BBG codes, TER, Repo)
    - Delega effettivo download alle API esistenti

    Note:
    - Cache gestita a livello API, non qui
    - HolidayManager è Singleton
    """

    def __init__(self,
                 bsh_client,
                 bbg_code_hard_coded_df: Optional[pd.DataFrame] = None,
                 ytm_mapping_df: Optional[pd.DataFrame] = None,
                 fx_mapping_df: Optional[pd.DataFrame] = None,
                 ter_hard_coding_df: Optional[pd.DataFrame] = None,
                 repo_hard_coding_df: Optional[pd.DataFrame] = None):
        """
        Inizializza l'adapter.

        Args:
            bsh_client: Istanza del BSHDataClient configurato
            bbg_code_hard_coded_df: DataFrame per override BBG codes (index=ISIN, col='BBG_CODE')
            ytm_mapping_df: DataFrame per mapping YTM (index=source_isin, col=target_isin)
            fx_mapping_df: DataFrame per mapping FX (index=source_isin, col=target_isin)
            ter_hard_coding_df: DataFrame per override TER (index=ISIN, col='TER')
            repo_hard_coding_df: DataFrame per override Repo (index=ISIN, col='Repo')
        """
        self._client = bsh_client

        # Hard coding overrides
        self._bbg_code_hard_coded_df = bbg_code_hard_coded_df if bbg_code_hard_coded_df is not None else pd.DataFrame()
        self._ter_hard_coding_df = ter_hard_coding_df if ter_hard_coding_df is not None else pd.DataFrame()
        self._repo_hard_coding_df = repo_hard_coding_df if repo_hard_coding_df is not None else pd.DataFrame()

        # Mapping DataFrames
        self._ytm_mapping_df = ytm_mapping_df if ytm_mapping_df is not None else pd.DataFrame()
        self._fx_mapping_df = fx_mapping_df if fx_mapping_df is not None else pd.DataFrame()

        # HolidayManager (Singleton)
        self._hm = HolidayManager()

    # ========================================================================
    # INSTRUMENT TYPES & METADATA
    # ========================================================================
    def get_index_additional_data(self, isin_list: List[str]) -> pd.DataFrame:
        """
        Ottiene dati aggiuntivi per Index.

        Args:
            isin_list: Lista di ISIN Index

        Returns:
            DataFrame con metadati Index
        """
        if not self._client:
            raise RuntimeError("Client non configurato")

        # TODO: Implementare query Oracle specifica per Index
        return pd.DataFrame({
            'UNDERLYING_TYPE': ['EQUITY'] * len(isin_list)
        }, index=isin_list)

    def get_cdx_additional_data(self, isin_list: List[str]) -> pd.DataFrame:
        """
        Ottiene dati aggiuntivi per CDX.

        Args:
            isin_list: Lista di ISIN CDX

        Returns:
            DataFrame con metadati CDX
        """
        if not self._client:
            raise RuntimeError("Client non configurato")

        # TODO: Implementare query Oracle specifica per CDX
        return pd.DataFrame(index=isin_list)

    # ========================================================================
    # DIVIDENDS
    # ========================================================================

    def download_dividends(self,
                          isin_list: List[str],
                          relevant_dates: List[dt.date],
                          bbg_codes_dict: Dict[str, str],
                          instrument_type: str = "STOCK") -> pd.DataFrame:
        """
        Scarica dividendi per una lista di ISIN.

        Args:
            isin_list: Lista di ISIN
            relevant_dates: Date rilevanti per cui scaricare dividendi
            bbg_codes_dict: Mapping ISIN -> Bloomberg code
            instrument_type: Tipo strumento (default "STOCK")

        Returns:
            DataFrame con dividendi percentuali (index=date, columns=ISIN)
        """
        if not self._client:
            logger.warning("Client non configurato - ritorno dividendi vuoti")
            return pd.DataFrame(0., index=relevant_dates, columns=isin_list)

        api = InfoDataAPI(self._client)

        start_date = relevant_dates[0]
        end_date = relevant_dates[-1]

        # Usa BBG codes se disponibili, altrimenti ISIN
        tickers = [bbg_codes_dict.get(isin, isin) for isin in isin_list]

        logger.info(f"Downloading dividends for {len(isin_list)} ISINs from {start_date} to {end_date}")

        # Scarica dividendi da Bloomberg
        result = api.get_dividends(
            isin=isin_list,
            id=isin_list,
            ticker=tickers,
            start=start_date,
            end=end_date,
            source="bloomberg",
            type=instrument_type
        )

        # Reindex per garantire tutte le date e ISIN richiesti
        return result.reindex(index=relevant_dates, columns=isin_list, fill_value=0.)

    # ========================================================================
    # TER (Total Expense Ratio)
    # ========================================================================

    def download_etf_ter(self,
                        isin_list: List[str],
                        relevant_dates: List[dt.date]) -> pd.DataFrame:
        """
        Scarica Total Expense Ratio per ETF.

        Logica:
        1. Scarica TER da Oracle
        2. Applica hard coding override
        3. Check missing e fallback Bloomberg
        4. Replica per tutte le date (TER è statico)

        Args:
            isin_list: Lista di ISIN ETF
            relevant_dates: Date rilevanti

        Returns:
            DataFrame con TER in decimali (index=date, columns=ISIN)
        """
        if not self._client:
            logger.warning("Client non configurato - ritorno TER vuoti")
            return pd.DataFrame(0., index=relevant_dates, columns=isin_list)

        api = InfoDataAPI(self._client)

        logger.info(f"Downloading TER for {len(isin_list)} ETFs")

        # Step 1: Scarica da Oracle
        ter_series = api.get_ter(isin=isin_list, source="oracle", fallback=[{"source": "bloomberg"}])

        # Step 2: Applica hard coding override
        if not self._ter_hard_coding_df.empty:
            logger.debug(f"Applying TER hard coding for {len(self._ter_hard_coding_df)} ISINs")
            ter_series.update(self._ter_hard_coding_df['TER'])

        # Step 4: Check ancora missing
        still_missing = ter_series.loc[ter_series.isna().any(axis=1)].index.tolist()

        if still_missing:
            logger.warning(f"No TER found for {len(still_missing)} ISINs: {still_missing}, using 0")

        ter_series.fillna(0, inplace=True)

        ter_df = pd.concat([ter_series for _ in relevant_dates], axis=1).T
        ter_df.index = relevant_dates

        return ter_df

    # ========================================================================
    # YTM (Yield to Maturity) con Mapping
    # ========================================================================

    def download_etf_ytm(self,
                        id_list: List[str],
                        relevant_dates: List[dt.date],
                        etf_coverage_threshold: float = 0.3) -> pd.DataFrame:
        """
        Scarica Yield to Maturity per ETF fixed income.

        Logica:
        1. Scarica YTM da TimescaleDB con fallback Bloomberg
        2. Applica mapping se configurato (usa YTM di altro ETF)
        3. Verifica che tutti abbiano YTM

        Args:
            id_list: Lista di ISIN ETF fixed income
            relevant_dates: Date rilevanti
            etf_coverage_threshold: Soglia coverage per TimescaleDB (default 0.3)

        Returns:
            DataFrame con YTM in decimali (index=date, columns=ISIN)

        Raises:
            Exception: Se YTM mancante e no mapping disponibile
        """
        if not self._client:
            logger.warning("Client non configurato - ritorno YTM vuoti")
            return pd.DataFrame(0., index=relevant_dates, columns=id_list)

        api = InfoDataAPI(self._client)
        start, end = relevant_dates[0], relevant_dates[-1]

        logger.info(f"Downloading YTM for {len(id_list)} ETFs from {start} to {end}")

        # Scarica YTM da TimescaleDB con fallback Bloomberg
        ytm_data = api.get(
            type="ETP",
            id=id_list,
            start=start,
            end=end,
            fields="YTM",
            source="timescale",
            autocomplete=True,
            coverage_threshold=etf_coverage_threshold,
            fallback={"source": "bloomberg"}
        )

        # Normalizza a DataFrame
        if isinstance(ytm_data, pd.Series):
            ytm_data = ytm_data.to_frame("YTM")
            ytm_data.columns = id_list

        # Reindex per garantire date e colonne corrette
        ytm_data = ytm_data.reindex(index=relevant_dates, columns=id_list)

        # Verifica che YTM mapping targets esistano
        if not self._ytm_mapping_df.empty:
            mapping_targets = self._ytm_mapping_df.iloc[:, 0].unique().tolist()
            missing_targets = [isin for isin in mapping_targets if isin not in ytm_data.columns]
            if missing_targets:
                raise Exception(
                    f"Cannot apply YTM mapping: target ISINs missing YTM data: {missing_targets}"
                )

        # Applica mapping
        mapped_columns = {}
        overridden_isins = []

        for isin in id_list:
            if isin in self._ytm_mapping_df.index:
                target_isin = self._ytm_mapping_df.loc[isin].iloc[0]

                # Se esiste già YTM, il mapping lo sovrascrive
                if isin in ytm_data.columns:
                    overridden_isins.append(isin)
                    ytm_data = ytm_data.drop(columns=isin)

                mapped_columns[isin] = ytm_data[target_isin]

        if overridden_isins:
            logger.warning(f"YTM mapping overrides existing data for: {overridden_isins}")

        if mapped_columns:
            ytm_data = pd.concat([ytm_data, pd.DataFrame(mapped_columns)], axis=1)

        # Verifica ISINs mancanti
        missing_isins = [isin for isin in id_list if isin not in ytm_data.columns]
        if missing_isins:
            raise Exception(
                f"No YTM found and no mapping configured for ETF(s): {missing_isins}"
            )

        # Converti da % a decimali
        return ytm_data[id_list] / 100

    def download_index_ytm(self,
                          isin_list: List[str],
                          relevant_dates: List[dt.date]) -> pd.DataFrame:
        """
        Scarica YTM per Index fixed income.

        Gli Index non hanno YTM diretta, devono usare mapping a ETF.

        Args:
            isin_list: Lista di ISIN Index fixed income
            relevant_dates: Date rilevanti

        Returns:
            DataFrame con YTM in decimali (index=date, columns=ISIN)

        Raises:
            Exception: Se mapping non configurato o target mancante
        """
        if self._ytm_mapping_df.empty:
            raise Exception(f"No YTM mapping configured for Index(es): {isin_list}")

        logger.info(f"Mapping YTM for {len(isin_list)} Indexes to ETF targets")

        # Gli Index devono mappare a ETF già scaricati
        # Questo metodo dovrebbe essere chiamato DOPO download_etf_ytm

        mapped_columns = {}

        for isin in isin_list:
            if isin not in self._ytm_mapping_df.index:
                raise Exception(f"No YTM mapping configured for Index: {isin}")

            target_isin = self._ytm_mapping_df.loc[isin].iloc[0]

            # Scarica YTM del target (ricorsivo - potrebbe essere ETF o Future)
            logger.debug(f"Fetching YTM for Index {isin} from target {target_isin}")

            # TODO: Implementare fetch da cache o API
            # Per ora assume che il target sia un ETF già scaricato
            raise NotImplementedError("Index YTM mapping requires cross-instrument cache")

        ytm_data = pd.DataFrame(mapped_columns)
        return ytm_data / 100

    def download_future_ytm(self,
                           isin_list: List[str],
                           relevant_dates: List[dt.date]) -> pd.DataFrame:
        """
        Scarica YTM per Future.

        Logica:
        1. Se esiste mapping future → target, usa il target
        2. Altrimenti scarica YTM diretta da TimescaleDB/Bloomberg

        Args:
            isin_list: Lista di ISIN Future
            relevant_dates: Date rilevanti

        Returns:
            DataFrame con YTM in decimali (index=date, columns=ISIN)
        """
        if not self._client:
            logger.warning("Client non configurato - ritorno YTM vuoti")
            return pd.DataFrame(0., index=relevant_dates, columns=isin_list)

        api = InfoDataAPI(self._client, autocomplete=True)
        ytm_df = pd.DataFrame(index=relevant_dates)

        logger.info(f"Downloading YTM for {len(isin_list)} Futures")

        # Step 1: Applica mapping dove presente
        mapped_series = {}

        for isin in isin_list:
            if isin in self._ytm_mapping_df.index:
                target_isin = self._ytm_mapping_df.loc[isin].iloc[0]
                logger.debug(f"Mapping Future {isin} YTM to target {target_isin}")

                # Scarica YTM del target
                target_series = api.get(
                    field="YTM",
                    id=target_isin,
                    source="timescale",
                    fallback={"source": "bloomberg"},
                )

                if target_series is not None:
                    mapped_series[isin] = target_series
                else:
                    logger.warning(f"YTM mapping target {target_isin} not found for {isin}")

        # Inserisci mapped
        if mapped_series:
            df_map = pd.DataFrame(mapped_series)
            ytm_df = ytm_df.join(df_map, how="left")

        # Step 2: Scarica YTM diretta per missing
        missing_isins = [isin for isin in isin_list if isin not in ytm_df.columns]

        if missing_isins:
            logger.info(f"Downloading direct YTM for {len(missing_isins)} Futures")

            for isin in missing_isins:
                ser = api.get(
                    fields="YTM",
                    id=isin,
                    start=relevant_dates[0],
                    end=relevant_dates[-1],
                    source="timescale",
                )

                if ser is None or ser.empty:
                    logger.error(f"YTM missing for Future {isin}, filling with zeros")
                    ser = pd.Series(0.0, index=relevant_dates)

                ytm_df[isin] = ser

        # Ordina colonne e converti da % a decimali
        return ytm_df.reindex(columns=isin_list) / 100

    # ========================================================================
    # FX
    # ========================================================================

    def download_fx(self,
                   fx_pairs: List[str],
                   relevant_dates: List[dt.date],
                   snipping_time: dt.time) -> pd.DataFrame:
        """
        Scarica tassi di cambio FX giornalieri.

        Args:
            fx_pairs: Lista di coppie FX (es. ['EURUSD', 'EURGBP'])
            relevant_dates: Date rilevanti
            snipping_time: Ora snapshot per fairvalue

        Returns:
            DataFrame con FX rates (index=date, columns=fx_pair)
        """
        if not self._client:
            logger.warning("Client non configurato - ritorno FX vuoti")
            return pd.DataFrame(1., index=relevant_dates, columns=fx_pairs)

        api = MarketDataAPI(self._client)
        start, end = relevant_dates[0], relevant_dates[-1]

        logger.info(f"Downloading FX for {len(fx_pairs)} pairs from {start} to {end}")

        fx_data = api.get_daily_currency(
            id=fx_pairs,
            start=start,
            end=end,
            snapshot_time=snipping_time,
            fallback={"source": "bloomberg"}
        )

        if isinstance(fx_data, pd.Series):
            fx_data = fx_data.to_frame()

        return fx_data.reindex(index=relevant_dates, columns=fx_pairs)

    def download_fxfwrd(self,
                       currencies: List[str],
                       start: dt.date,
                       end: dt.date,
                       snipping_time: dt.time) -> pd.DataFrame:
        """
        Scarica FX forward rates.

        Args:
            currencies: Lista di valute
            start: Data inizio
            end: Data fine
            snipping_time: Ora snapshot

        Returns:
            DataFrame con FX forward rates
        """
        if not self._client:
            logger.warning("Client non configurato - ritorno FX forward vuoti")
            return pd.DataFrame()

        api = MarketDataAPI(self._client)

        logger.info(f"Downloading FX forward for {len(currencies)} currencies")

        return api.get(
            type=InstrumentType.FXFWD,
            id=currencies,
            start=start,
            end=end,
            snapshot_time=snipping_time,
            source="bloomberg",
            request_type="historical"
        )

    # ========================================================================
    # FX COMPOSITION con Mapping
    # ========================================================================

    def download_etf_fx_composition(self,
                                   isin_list: List[str],
                                   relevant_dates: List[dt.date],
                                   coverage_threshold: float = 0.0,
                                    ) -> Dict[str, pd.DataFrame]:
        """
        Scarica composizione FX per ETF.

        Logica:
        1. Scarica da Oracle
        2. Filtra per coverage threshold
        3. Applica mapping se configurato

        Args:
            isin_list: Lista di ISIN ETF
            relevant_dates: Date rilevanti
            coverage_threshold: Soglia minima peso FX (default 0.0 = tutti)

        Returns:
            Dict con 'fx' e 'fxfwd' DataFrames (index=ISIN, columns=CURRENCY)
        """
        if not self._client:
            logger.warning("Client non configurato - ritorno FX composition vuoti")
            return {'fx': pd.DataFrame(), 'fxfwd': pd.DataFrame()}

        api = InfoDataAPI(self._client)
        reference_date = relevant_dates[-1]

        logger.info(f"Downloading FX composition for {len(isin_list)} ETFs (threshold={coverage_threshold})")

        # Scarica FX spot e forward separatamente
        fx_data = api.get_fx_composition(
            id=isin_list,
            reference_date=reference_date,
            fx_fxfwrd="fx",
            autocomplete=True
        )

        fx_fwd_data = api.get_fx_composition(
            id=isin_list,
            reference_date=reference_date,
            fx_fxfwrd="fxfwrd"
        )

        # Filtra per coverage threshold
        if coverage_threshold > 0:
            fx_data = fx_data[fx_data >= coverage_threshold].fillna(0.)
            fx_fwd_data = fx_fwd_data[fx_fwd_data >= coverage_threshold].fillna(0.)

        # Applica mapping se configurato
        if not self._fx_mapping_df.empty:
            logger.debug(f"Applying FX composition mapping for {len(self._fx_mapping_df)} ISINs")

            # Verifica che mapping targets esistano
            mapping_targets = self._fx_mapping_df.iloc[:, 0].unique().tolist()
            missing_targets = [isin for isin in mapping_targets if isin not in fx_data.index]

            if missing_targets:
                raise Exception(
                    f"Cannot apply FX mapping: target ISINs missing: {missing_targets}"
                )

            # Applica mapping
            mapped_rows_fx = {}
            mapped_rows_fx_fwd = {}

            for isin in isin_list:
                if isin in self._fx_mapping_df.index and isin not in fx_data.index:
                    target_isin = self._fx_mapping_df.loc[isin].iloc[0]
                    mapped_rows_fx[isin] = fx_data.loc[target_isin]
                    mapped_rows_fx_fwd[isin] = fx_fwd_data.loc[target_isin]

            if mapped_rows_fx:
                fx_data = pd.concat([fx_data, pd.DataFrame.from_dict(mapped_rows_fx, orient='index')])
                fx_fwd_data = pd.concat([fx_fwd_data, pd.DataFrame.from_dict(mapped_rows_fx_fwd, orient='index')])

        # Verifica ISINs mancanti
        missing_isins = [isin for isin in isin_list if isin not in fx_data.index]
        if missing_isins:
            raise Exception(
                f"No FX composition found and no mapping configured for ETF(s): {missing_isins}"
            )

        return {'fx': fx_data, 'fxfwd': fx_fwd_data}

    # ========================================================================
    # REPO RATES con Hard Coding
    # ========================================================================

    def download_future_repo(self,
                            isin_list: List[str],
                            relevant_dates: List[dt.date],
                            currency_dict: Dict[str, str]) -> pd.DataFrame:
        """
        Scarica repo rates per Future.

        Logica:
        1. Applica hard coding se presente
        2. Scarica repo per currency da TimescaleDB
        3. Mappa currency -> ISIN

        Args:
            isin_list: Lista di ISIN Future
            relevant_dates: Date rilevanti
            currency_dict: Mapping ISIN -> Currency

        Returns:
            DataFrame con repo rates in decimali (index=date, columns=ISIN)
        """
        if not self._client:
            logger.warning("Client non configurato - ritorno repo rates vuoti")
            return pd.DataFrame(0., index=relevant_dates, columns=isin_list)

        repo_df = pd.DataFrame(index=relevant_dates)

        logger.info(f"Downloading repo rates for {len(isin_list)} Futures")

        # Step 1: Applica hard coding se presente
        for isin in isin_list:
            if isin in self._repo_hard_coding_df.index:
                repo_value = self._repo_hard_coding_df.loc[isin, 'Repo']
                repo_df[isin] = repo_value
                logger.debug(f"Applied repo hard coding for {isin}: {repo_value}")

        # Step 2: Scarica repo per currency per ISIN non hard-coded
        currencies = list(set(currency_dict.values()))
        repo_per_currency = self._download_repo_per_currency(currencies, relevant_dates)

        # Step 3: Mappa currency -> ISIN
        for isin in isin_list:
            if isin not in repo_df.columns:
                ccy = currency_dict[isin]
                repo_df[isin] = repo_per_currency[ccy]

        # Converti da % a decimali
        return repo_df[isin_list] / 100

    def _download_repo_per_currency(self,
                                    currencies: List[str],
                                    relevant_dates: List[dt.date]) -> pd.DataFrame:
        """
        Scarica overnight financing rates per currency.

        Mappa automaticamente currency -> repo index (es. EUR -> ESTRON).

        Args:
            currencies: Lista di valute (es. ['EUR', 'USD'])
            relevant_dates: Date rilevanti

        Returns:
            DataFrame con repo rates (index=date, columns=currency)
        """
        api = MarketDataAPI(self._client)

        logger.info(f"Downloading repo rates for {len(currencies)} currencies")

        # Mappa currency → repo index
        currency_to_repo = {
            c: CURRENCY_FINANCING_RATES_MAPPING.get(c)
            for c in currencies
        }

        # Repo indices unici da scaricare
        repo_list = list({r for r in currency_to_repo.values() if r is not None})

        if not repo_list:
            logger.warning(f"No repo indices found for currencies: {currencies}")
            return pd.DataFrame(0., index=relevant_dates, columns=currencies)

        # Scarica da TimescaleDB con fallback Bloomberg
        repo_data = api.get(
            type="INDEX",
            id=repo_list,
            source="timescale",
            start=relevant_dates[0],
            end=relevant_dates[-1],
            fallback=[{"source": "bloomberg"}],
        )

        # Normalizza a DataFrame
        if isinstance(repo_data, pd.Series):
            repo_data = repo_data.to_frame(name="overnight_rate")
            repo_data.columns = repo_list

        # Crea mapping inverso repo -> list of currencies
        repo_to_currencies = {}
        for currency, repo in currency_to_repo.items():
            if repo:
                repo_to_currencies.setdefault(repo, []).append(currency)

        # Rimappa colonne da repo indices a currencies
        out = pd.DataFrame({
            currency: repo_data[repo]
            for repo, currencies_list in repo_to_currencies.items()
            if repo in repo_data.columns
            for currency in currencies_list
        }, index=repo_data.index)

        # Reindex per garantire tutte le date e currencies
        return out.reindex(columns=currencies, index=relevant_dates, fill_value=0.)

    # ========================================================================
    # CDX PRICES
    # ========================================================================

    def download_cdx_prices(self,
                           id_list: List[str],
                           relevant_dates: List[dt.date],
                           snapshot_time: dt.time = dt.time(17, 0)) -> pd.DataFrame:
        """
        Scarica prezzi CDX.

        Args:
            id_list: Lista di CDX IDs
            relevant_dates: Date rilevanti
            snapshot_time: Ora snapshot (default 17:00)

        Returns:
            DataFrame con prezzi CDX
        """
        if not self._client:
            logger.warning("Client non configurato - ritorno CDX prices vuoti")
            return pd.DataFrame()

        api = MarketDataAPI(self._client)

        # Usa previous business day per start (CDX pricing convention)
        start = self._hm.previous_business_day(relevant_dates[0])
        end = relevant_dates[-1]

        logger.info(f"Downloading CDX prices for {len(id_list)} indices from {start} to {end}")

        return api.get(
            type="CDXINDEX",
            id=id_list,
            start=start,
            end=end,
            source="bloomberg",
            request_type="reference",
            autocomplete=True,
            frequency="daily",
            snapshot_time=snapshot_time
        )


# ========================================================================
# COSTANTI E MAPPING
# ========================================================================

# Mapping tra valute e tassi di finanziamento overnight
CURRENCY_FINANCING_RATES_MAPPING = {
    'EUR': 'ESTRON',
    'USD': 'SOFRRATE',
    'GBP': 'SONIO/N',
    'AUD': 'RBACOR',
    'CHF': 'SRFXON3',
    'JPY': 'TONAR'
}

# Mapping inverso
FINANCING_RATES_CURRENCY_MAPPING = {v: k for k, v in CURRENCY_FINANCING_RATES_MAPPING.items()}

# Mapping mesi futures
FUTURES_DLV_MONTHS_MAPPING = {
    1: "F", 2: "G", 3: "H", 4: "J", 5: "K", 6: "M",
    7: "N", 8: "Q", 9: "U", 10: "V", 11: "X", 12: "Z"
}

FUTURES_CHAR_TO_DLV_MONTHS_MAPPING = {v: k for k, v in FUTURES_DLV_MONTHS_MAPPING.items()}

FUTURE_EXPIRY_MONTHS = [3, 6, 9, 12]

# FX Forward mapping
FX_FORWARD_MAPPING: Dict[str, str] = {
    "EURUSD": "EUR1M BGN Curncy",
    "EURGBP": "EURGBP1M Curncy",
    "EURCNH": "EURCNH1M Curncy",
    "EURJPY": "EURJPY1M Curncy",
    "EURAUD": "EURAUD1M Curncy",
    "EURCAD": "EURCAD1M Curncy",
    "EURCHF": "EURCHF1M Curncy",
    "EURINR": "EURINR1M Curncy",
    "EURIDR": "EURIDR1M Curncy",
    "EURRON": "EURRON1M Curncy",
    "EURMXN": "EURMXN1M Curncy",
    "EURZAR": "EURZAR1M Curncy",
    "EURKRW": "EURKRW1M Curncy",
    "EURCOP": "EURCOP1M Curncy",
    "EURCZK": "EURCZK1M Curncy",
    "EURMYR": "EURMYR1M Curncy",
    "EURPLN": "EURPLN1M Curncy",
    "EURTHB": "EURTHB1M Curncy",
    "EURBRL": "EURBRL1M Curncy",
}