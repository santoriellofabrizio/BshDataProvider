"""
Funzioni di utility per calcoli di date e altre operazioni comuni.
"""
import datetime as dt
from typing import List
import pandas as pd


def get_contiguous_date(date: dt.date, days_offset: int) -> dt.date:
    """
    Ottiene una data contigua (giorni lavorativi) a partire da una data di riferimento.

    Args:
        date: Data di riferimento
        days_offset: Numero di giorni da aggiungere/sottrarre (positivo o negativo)

    Returns:
        Data contigua risultante
    """
    current_date = date
    direction = 1 if days_offset > 0 else -1
    remaining_days = abs(days_offset)

    while remaining_days > 0:
        current_date += dt.timedelta(days=direction)
        # Salta i weekend
        if current_date.weekday() < 5:  # 0-4 sono lun-ven
            remaining_days -= 1

    return current_date


def generate_date_range(start_date: dt.date, end_date: dt.date, business_days_only: bool = True) -> List[dt.date]:
    """
    Genera una lista di date tra start e end.

    Args:
        start_date: Data inizio
        end_date: Data fine
        business_days_only: Se True, include solo giorni lavorativi

    Returns:
        Lista di date
    """
    dates = []
    current = start_date

    while current <= end_date:
        if not business_days_only or current.weekday() < 5:
            dates.append(current)
        current += dt.timedelta(days=1)

    return dates


def calculate_year_fraction(start_date: dt.date, end_date: dt.date, day_count_convention: str = 'ACT/365') -> float:
    """
    Calcola la frazione di anno tra due date secondo una convenzione.

    Args:
        start_date: Data inizio
        end_date: Data fine
        day_count_convention: Convenzione di calcolo ('ACT/365', 'ACT/360', '30/360', etc)

    Returns:
        Frazione di anno
    """
    days = (end_date - start_date).days

    if day_count_convention == 'ACT/365':
        return days / 365.0
    elif day_count_convention == 'ACT/360':
        return days / 360.0
    elif day_count_convention == '30/360':
        # Simplified 30/360 calculation
        y1, m1, d1 = start_date.year, start_date.month, start_date.day
        y2, m2, d2 = end_date.year, end_date.month, end_date.day
        return ((y2 - y1) * 360 + (m2 - m1) * 30 + (d2 - d1)) / 360.0
    else:
        raise ValueError(f"Day count convention '{day_count_convention}' not supported")


def align_dataframes_to_dates(df: pd.DataFrame, target_dates: List[dt.date],
                              fill_method: str = 'ffill') -> pd.DataFrame:
    """
    Allinea un DataFrame a una lista di date target.

    Args:
        df: DataFrame con index di date
        target_dates: Lista di date target
        fill_method: Metodo di riempimento ('ffill', 'bfill', 'zero')

    Returns:
        DataFrame allineato alle date target
    """
    result = df.reindex(target_dates)

    if fill_method == 'ffill':
        result = result.fillna(method='ffill')
    elif fill_method == 'bfill':
        result = result.fillna(method='bfill')
    elif fill_method == 'zero':
        result = result.fillna(0)

    return result


def is_business_day(date: dt.date, holidays: List[dt.date] = None) -> bool:
    """
    Verifica se una data è un giorno lavorativo.

    Args:
        date: Data da verificare
        holidays: Lista di festività (opzionale)

    Returns:
        True se è un giorno lavorativo
    """
    # Weekend check
    if date.weekday() >= 5:
        return False

    # Holidays check
    if holidays and date in holidays:
        return False

    return True