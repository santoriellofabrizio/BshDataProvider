"""
Base abstract class per tutti gli strumenti finanziari.
Definisce l'interfaccia comune per il calcolo dei ritorni aggiustati.
"""
from abc import ABC, abstractmethod
import pandas as pd


class BaseInstrumentClass(ABC):
    """Classe base astratta per tutti gli strumenti finanziari."""

    @abstractmethod
    def download_data(self):
        """Scarica i dati necessari per lo strumento."""
        pass

    @abstractmethod
    def clean_returns(self, returns_df: pd.DataFrame, cumulative: bool) -> pd.DataFrame:
        """
        Pulisce i ritorni applicando aggiustamenti e correzioni FX.

        Args:
            returns_df: DataFrame con i ritorni da pulire
            cumulative: Se True, applica correzioni cumulative

        Returns:
            DataFrame con ritorni puliti
        """
        pass

    @abstractmethod
    def get_adjustments(self) -> pd.DataFrame:
        """
        Calcola gli aggiustamenti ai ritorni (dividendi, repo, etc).

        Returns:
            DataFrame con aggiustamenti per data e ISIN
        """
        pass

    @abstractmethod
    def get_fx_corrections(self) -> pd.DataFrame:
        """
        Calcola le correzioni per effetti FX.

        Returns:
            DataFrame con correzioni FX per data e ISIN
        """
        pass

    @abstractmethod
    def on_fx_update(self, fx_update: pd.Series):
        """
        Callback chiamato quando i tassi FX vengono aggiornati.

        Args:
            fx_update: Serie con i nuovi tassi FX spot
        """
        pass