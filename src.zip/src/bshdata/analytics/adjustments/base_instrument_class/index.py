import datetime as dt
import logging
from typing import List
import pandas as pd

from bshdata.analytics.adjustments.base_instrument_class import BaseInstrumentClassMeta
from bshdata.core.instruments.instruments import Instrument

logger = logging.getLogger(__name__)


class IndexClass(BaseInstrumentClassMeta):
    """
    Implementazione degli Index per il calcolo degli adjusted returns.
    Architettura identica a FutureClass:
      - stessa public API: get_adjustments()
      - download_ytm()
      - daily adjustments con year fractions
      - controlli duplicati / tipi non supportati
    """

    def __init__(
            self,
            instruments: List[Instrument],
            data_downloader,
            relevant_dates: List[dt.date],
            settlement_type: pd.Series,
    ):
        # validazione duplicati
        ids = [inst.id for inst in instruments]
        self._check_duplicates(ids)

        # container
        self._index_data = pd.DataFrame()
        self._index_ytm = pd.DataFrame()

        super().__init__(instruments, data_downloader, relevant_dates, settlement_type)

        self._adjustments = pd.DataFrame()

    # ======================================================================
    # HELPER PROPERTIES
    # ======================================================================
    @property
    def _ids(self):
        return [i.id for i in self._instruments]

    # ======================================================================
    # PUBLIC API
    # ======================================================================
    def get_adjustments(self) -> pd.DataFrame:
        """
        Ritorna DataFrame(index=relevant_dates, columns=ids).
        Nel caso degli Indici:
            - FI Index:     - ytm * year_fraction
            - Equity Index: 0
        """
        try:
            self.download_data()
        except Exception as e:
            self._logger.exception("Error downloading Index data: %s", e)

        adjustments = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)

        for day in self._relevant_dates:
            try:
                daily = self._get_daily_adjustments(day)
            except Exception as e:
                self._logger.exception("Daily adjustments failed for %s: %s", day, e)
                daily = pd.Series(0.0, index=self._ids)

            adjustments.loc[day] = daily

        self._adjustments = adjustments
        return adjustments

    def download_data(self):
        """Scarica metadata + ytm."""
        self._get_individual_instrument_data()
        self._download_ytm()

    # ======================================================================
    # DAILY ADJUSTMENTS
    # ======================================================================
    def _get_daily_adjustments(self, day: dt.date) -> pd.Series:
        daily = pd.Series(0.0, index=self._ids)

        year_frac = self._shifted_year_fractions.loc[day]

        # Solo FI Index hanno YTM
        if not self._index_ytm.empty and day in self._index_ytm.index:
            daily -= (
                self._index_ytm.loc[day]
                .reindex(self._ids, fill_value=0.0)
                * year_frac
            )

        return daily

    # ======================================================================
    # DOWNLOADS
    # ======================================================================
    def _get_individual_instrument_data(self):
        """Scarica info sui singoli indici."""
        self._index_data = self._data_downloader.get_index_additional_data(self._ids)

        self._check_index_data(self._index_data)

    def _download_ytm(self):
        """Scarica YTM per gli indici Fixed Income."""
        self._logger.info("Downloading Index YTM...")

        try:
            fi_list = self._index_data[
                self._index_data["INDEX_TYPE"] == "FIXED INCOME"
            ].index.tolist()

            if fi_list:
                ytm = self._data_downloader.download_index_ytm(fi_list, self._relevant_dates)
            else:
                ytm = pd.DataFrame()

            # allineo
            aligned = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
            if not ytm.empty:
                aligned.update(ytm)

            self._index_ytm = aligned

        except Exception as e:
            self._logger.exception("Index YTM download failed: %s", e)
            self._index_ytm = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)

        self._logger.info("Index YTM Download Complete!\n")

    # ======================================================================
    # VALIDAZIONI
    # ======================================================================
    @staticmethod
    def _check_index_data(index_data: pd.DataFrame):
        implemented = ["EQUITY", "FIXED INCOME"]
        received = index_data["INDEX_TYPE"].drop_duplicates().tolist()

        for t in received:
            if t not in implemented:
                raise Exception(f"The index underlying type {t} is not yet implemented.")

    @staticmethod
    def _check_duplicates(ids: List[str]):
        duplicates = [x for x in set(ids) if ids.count(x) > 1]
        if duplicates:
            raise Exception(f"The following indexes are repeated: {duplicates}")
