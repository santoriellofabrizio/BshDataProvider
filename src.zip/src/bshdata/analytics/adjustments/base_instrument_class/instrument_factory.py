"""
Factory per la creazione di strumenti Analytics.
Riceve Instrument già creati e li raggruppa per tipo.
"""
import logging
from typing import Dict, Type, List
import datetime as dt
import pandas as pd

from bshdata.analytics.adjustments.base_instrument_class import StockClass
from bshdata.analytics.adjustments.base_instrument_class.base_instrument import BaseInstrumentClass
from bshdata.analytics.adjustments.base_instrument_class.cdx import CDXClass
from bshdata.analytics.adjustments.base_instrument_class.etf import ETFClass
from bshdata.analytics.adjustments.base_instrument_class.future import FutureClass
from bshdata.analytics.adjustments.base_instrument_class.index import IndexClass
from bshdata.analytics.logger import AnalyticsLogger
from bshdata.core.instruments.instruments import Instrument, CDXIndexInstrument
from bshdata.core.enums.instrument_types import InstrumentType

logger = logging.getLogger(__name__)


def register_all_instrument_types(factory):
    """
    Registra tutti i tipi di strumento disponibili nella factory.

    Args:
        factory: Istanza di PipelineClassFactory
    """
    # Registra per InstrumentType enum
    factory.register_instrument_type(InstrumentType.STOCK, StockClass) # Alias
    factory.register_instrument_type(InstrumentType.ETP, ETFClass)
    factory.register_instrument_type(InstrumentType.FUTURE, FutureClass)
    factory.register_instrument_type(InstrumentType.INDEX, IndexClass)
    factory.register_instrument_type(InstrumentType.CDXINDEX, CDXClass)

    # TODO: Aggiungere altri strumenti quando pronti
    # factory.register_instrument_type(InstrumentType.ETP, ETFClass)
    # etc...


class PipelineClassFactory:
    """
    Factory pattern per la creazione di strumenti Analytics.

    Questa factory riceve Instrument già creati (da BshDataProvider),
    li raggruppa automaticamente per tipo, e crea le classi Analytics
    appropriate (StockClass, ETFClass, etc.) per ogni gruppo.

    NON crea Instrument - li riceve già pronti!
    """

    def __init__(self):
        """Inizializza la factory e registra tutti i tipi di strumento."""
        self.instrument_register: Dict[InstrumentType, Type[BaseInstrumentClass]] = {}
        register_all_instrument_types(self)

    def create_pipeline_class(self,
                                instrument_list: List[Instrument],
                                data_downloader,
                                relevant_dates: List[dt.date],
                                settlement_type: pd.Series,
                                **kwargs) -> Dict[InstrumentType, BaseInstrumentClass]:
        """
        Crea istanze di strumenti Analytics raggruppate per tipo.
        """

        if not instrument_list:
            raise ValueError("instrument_list cannot be empty")

        # Raggruppa per tipo di strumento
        grouped_by_type: Dict[InstrumentType, List[Instrument]] = {}

        for instrument in instrument_list:
            instrument_type = instrument.type

            if instrument_type not in grouped_by_type:
                grouped_by_type[instrument_type] = []

            grouped_by_type[instrument_type].append(instrument)

        logger.info(
            f"Grouped {len(instrument_list)} instruments into {len(grouped_by_type)} types: {[str(t) for t in grouped_by_type.keys()]}")

        # Crea le classi Analytics per ogni gruppo
        pipeline_class: Dict[InstrumentType, BaseInstrumentClass] = {}

        for instrument_type, instruments in grouped_by_type.items():
            if instrument_type not in self.instrument_register:
                available = [str(t) for t in self.instrument_register.keys()]
                logger.error(f"Instrument type '{instrument_type}' not registered. Available: {available}")
                raise KeyError(
                    f"Instrument type '{instrument_type}' not registered. "
                    f"Available types: {available}"
                )

            instrument_class = self.instrument_register[instrument_type]
            logger.info(f"Creating {instrument_class.__name__} with {len(instruments)} instruments")

            # Filtra settlement_type per questo gruppo di ISIN
            isins = [inst.isin for inst in instruments]
            group_settlement = settlement_type.loc[isins] if not settlement_type.empty else pd.Series(
                ['T+2'] * len(isins), index=isins)

            # NUOVO: Filtra kwargs in base alla classe
            class_kwargs = self._filter_kwargs_for_class(instrument_class, kwargs)

            pipeline_class[instrument_type] = instrument_class(
                instruments=instruments,
                data_downloader=data_downloader,
                relevant_dates=relevant_dates,
                settlement_type=group_settlement,
                **class_kwargs  # <- Usa kwargs filtrati
            )

        return pipeline_class

    @staticmethod
    def _filter_kwargs_for_class(instrument_class, kwargs: dict) -> dict:
        """
        Filtra kwargs per passare solo quelli accettati dalla classe.

        Args:
            instrument_class: Classe Analytics (StockClass, ETFClass, etc.)
            kwargs: Dizionario completo di kwargs

        Returns:
            Dizionario filtrato con solo kwargs validi per la classe
        """
        import inspect

        # Ottieni parametri __init__ della classe
        sig = inspect.signature(instrument_class.__init__)
        valid_params = set(sig.parameters.keys()) - {'self'}

        # Filtra kwargs
        filtered = {k: v for k, v in kwargs.items() if k in valid_params}

        return filtered

    def register_instrument_type(self, instrument_type: InstrumentType, instrument_class: Type[BaseInstrumentClass]) -> None:
        """
        Registra un nuovo tipo di strumento nella factory.

        Args:
            instrument_type: InstrumentType enum
            instrument_class: Classe dello strumento Analytics
        """
        self.instrument_register[instrument_type] = instrument_class

    def get_registered_types(self) -> List[InstrumentType]:
        """
        Restituisce la lista dei tipi di strumento registrati.

        Returns:
            Lista degli InstrumentType registrati
        """
        return list(self.instrument_register.keys())