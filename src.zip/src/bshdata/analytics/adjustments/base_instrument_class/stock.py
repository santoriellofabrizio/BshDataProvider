"""
StockClass - Strumento per azioni.
"""
import datetime as dt
import logging
from typing import List
import pandas as pd

from bshdata.analytics.adjustments.base_instrument_class import BaseInstrumentClassMeta
from bshdata.analytics.logger import AnalyticsLogger
from bshdata.core.instruments.instruments import Instrument, StockInstrument

logger = logging.getLogger(__name__)


class StockClass(BaseInstrumentClassMeta):
    """
    Strumento Stock - gestisce il calcolo dei ritorni aggiustati per azioni.

    Aggiustamenti:
    - Dividendi (income positivo)
    """

    def __init__(self,
                 instruments: List[Instrument],
                 data_downloader,
                 relevant_dates: List[dt.date],
                 settlement_type: pd.Series):
        """
        Inizializza StockClass.

        Args:
            instruments: Lista di StockInstrument già creati
            data_downloader: ProviderAdapter per scaricare dati
            relevant_dates: Date rilevanti per i calcoli
            settlement_type: Serie con tipo settlement
            logger: Logger per operazioni
        """
        # Verifica che siano tutti StockInstrument
        for inst in instruments:
            if not isinstance(inst, StockInstrument):
                raise TypeError(
                    f"Expected StockInstrument, got {type(inst).__name__} for {inst.isin}"
                )

        super().__init__(instruments, data_downloader, relevant_dates, settlement_type)

    def download_data(self):
        """
        Scarica i dati necessari per le azioni.

        CHIAMATA DIRETTA a ProviderAdapter (no wrapper)!
        """
        logger.info('Downloading stock dividends...', self)
        isins = [i.isin for i in self._instruments]

        # CHIAMATA DIRETTA al ProviderAdapter
        self._dividends = self._data_downloader.download_dividends(
            isin_list=isins,
            relevant_dates=self._relevant_dates,
            instrument_type="STOCK"
        )

        self._logger.info('Stock dividends download complete!\n', self)

    def _get_daily_adjustments(self, day: dt.date) -> pd.Series:
        """
        Calcola aggiustamenti giornalieri per le azioni.

        Aggiustamento = + Dividendi

        Args:
            day: Data per cui calcolare gli aggiustamenti

        Returns:
            Serie con aggiustamenti per ogni ISIN
        """
        daily_adjustments = pd.Series(0., index=self._isin_list)

        # Aggiungi dividendi se presenti
        if not self._dividends.empty and day in self._dividends.index:
            daily_adjustments += self._dividends.loc[day]

        return daily_adjustments
