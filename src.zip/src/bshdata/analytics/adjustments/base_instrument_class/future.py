import datetime as dt
import logging
from typing import List
import pandas as pd

from bshdata.analytics.adjustments.base_instrument_class import BaseInstrumentClassMeta
from bshdata.core.instruments.instruments import Instrument, FutureInstrument, FixedIncomeFuture

logger = logging.getLogger(__name__)


class FutureClass(BaseInstrumentClassMeta):
    """
    Implementazione dei Future per il calcolo degli adjusted returns.
    Architettura identica a ETFClass:
      - stessa public API: get_adjustments()
      - download_ytm(), download_repo(), metadata
      - daily adjustments con year fractions
      - issuance mask
      - struttura coerente e robusta
    """

    def __init__(
            self,
            instruments: List[Instrument],
            data_downloader,
            relevant_dates: List[dt.date],
            settlement_type: pd.Series,
    ):
        # validazione: tutti FutureInstrument
        for inst in instruments:
            if not isinstance(inst, FutureInstrument):
                raise TypeError(
                    f"Expected FutureInstrument, got {type(inst).__name__} for {getattr(inst, 'isin', '<unknown>')}"
                )

        # container dei dati
        self._future_data = pd.DataFrame()
        self._future_ytm = pd.DataFrame()
        self._future_repo = pd.DataFrame()

        # eredita: _instruments, _isin_list, _relevant_dates, _shifted_year_fractions, _logger, ecc.
        super().__init__(instruments, data_downloader, relevant_dates, settlement_type)

        # adjustments cache
        self._adjustments = pd.DataFrame()

    # ==========================================================================
    # HELPER PROPERTIES
    # ==========================================================================
    @property
    def _ids(self) -> List[str]:
        """Lista ID strumenti (usato ovunque)."""
        return [i.id for i in self._instruments]

    # ==========================================================================
    # PUBLIC API
    # ==========================================================================
    def get_adjustments(self) -> pd.DataFrame:
        """
        Ritorna DataFrame(index=relevant_dates, columns=isin) con:
            - YTM carry : -(ytm * shifted_year_fraction)
            + repo carry: +(repo * shifted_year_fraction)
        """

        # scarico i dati principali
        try:
            self.download_data()
        except Exception as e:
            self._logger.exception("Error downloading Future data: %s", e)

        # costruisco adjustments
        adjustments = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)

        for day in self._relevant_dates:
            try:
                daily = self._get_daily_adjustments(day)
            except Exception as e:
                self._logger.exception("Daily adjustments failed for %s: %s", day, e)
                daily = pd.Series(0.0, index=self._ids)

            adjustments.loc[day] = daily

        self._adjustments = adjustments
        return adjustments

    def download_data(self):
        """Scarica YTM + Repo."""
        self._download_ytm()
        self._download_repo()

    # ==========================================================================
    # DAILY ADJUSTMENTS
    # ==========================================================================
    def _get_daily_adjustments(self, day: dt.date) -> pd.Series:
        """
        Regole Future:
            - YTM:  - ytm * shifted_year_fraction
            + Repo: + repo * shifted_year_fraction
        """
        # fallback se non ci sono year fractions
        if getattr(self, "_shifted_year_fractions", None) is None or self._shifted_year_fractions.empty:
            self._shifted_year_fractions = pd.Series(1 / 252, index=self._relevant_dates)

        year_frac = self._shifted_year_fractions.loc[day]
        daily = pd.Series(0.0, index=self._ids)

        # YTM
        if not self._future_ytm.empty and day in self._future_ytm.index:
            daily -= self._future_ytm.loc[day].reindex(self._ids, fill_value=0.0) * year_frac

        # Repo
        if not self._future_repo.empty and day in self._future_repo.index:
            daily += self._future_repo.loc[day].reindex(self._ids, fill_value=0.0) * year_frac

        # mask per strumenti non ancora emessi !todo aggiungi nel caso maschera per issue date
        if not self._future_data.empty and "ISSUE_DATE" in self._future_data.columns:
            issued = self._future_data["ISSUE_DATE"].apply(
                lambda d: (d <= day) if pd.notnull(d) else False
            )
            daily[~issued.reindex(self._ids, fill_value=False)] = 0.0

        return daily

    # ==========================================================================
    # HELPER: Allineamento DataFrame
    # ==========================================================================


    # ==========================================================================
    # DOWNLOADS
    # ==========================================================================
    def _download_ytm(self):
        """Scarica YTM solo per Fixed Income Future."""
        self._logger.info("Downloading Future YTM...")

        try:
            fi_instruments = [i for i in self._instruments if isinstance(i, FixedIncomeFuture)]

            if fi_instruments:
                fi_ids = [i.id for i in fi_instruments]
                ytm = self._data_downloader.download_future_ytm(fi_ids, self._relevant_dates)
            else:
                ytm = pd.DataFrame()

            self._future_ytm = self._align_dataframe(ytm, "YTM")

        except Exception as e:
            self._logger.exception("Future YTM download failed: %s", e)
            self._future_ytm = self._align_dataframe(None, "YTM")

    def _download_repo(self):
        """Scarica Repo per tutti i Future."""
        self._logger.info("Downloading Future Repo...")

        try:
            # Costruisci mapping currency
            currency_map = {
                (instrument.isin or instrument.id): (
                    instrument.currency.value
                    if hasattr(instrument.currency, "value")
                    else instrument.currency
                )
                for instrument in self._instruments
                if instrument.currency
            }

            repo = self._data_downloader.download_future_repo(
                self._ids, self._relevant_dates, currency_map
            )

            self._future_repo = self._align_dataframe(repo, "Repo")

        except Exception as e:
            self._logger.exception("Future Repo download failed: %s", e)
            self._future_repo = self._align_dataframe(None, "Repo")