"""
BaseInstrumentClass - Classe base con logica comune per tutti gli strumenti.
"""
import datetime as dt
import logging
from typing import List, Dict
import pandas as pd
from abc import abstractmethod

from bshdata.analytics.adjustments.base_instrument_class.base_instrument import BaseInstrumentClass
from bshdata.analytics.adjustments.downloaders import ProviderAdapter
from bshdata.core.instruments.instruments import Instrument
from bshdata.analytics.adjustments.utils import calculate_year_fraction


class BaseInstrumentClassMeta(BaseInstrumentClass):
    """
    Classe base per strumenti Analytics.

    Fornisce:
    - Gestione Instrument (composizione)
    - Calcolo year fractions (standard e shifted per settlement)
    - Framework per aggiustamenti e FX corrections
    - NESSUN wrapper - le subclass chiamano direttamente ProviderAdapter
    """

    def __init__(self,
                 instruments: List[Instrument],
                 data_downloader: ProviderAdapter,
                 relevant_dates: List[dt.date],
                 settlement_type: pd.Series):
        """
        Inizializza la classe base.

        Args:
            instruments: Lista di Instrument già creati
            data_downloader: ProviderAdapter per scaricare dati
            relevant_dates: Date rilevanti per i calcoli
            settlement_type: Serie con tipo settlement per ISIN
            logger: Logger per operazioni
        """
        logger = logging.getLogger(__name__)
        self._instruments: List[Instrument] = instruments
        self._data_downloader = data_downloader
        self._relevant_dates: List[dt.date] = relevant_dates
        self._settlement_type: pd.Series = settlement_type
        self._logger = logger

        # Estrai info dagli Instrument
        self._bbg_codes_dict: Dict[str, str] = {
            inst.isin: inst.ticker if inst.ticker else inst.isin
            for inst in instruments
        }
        self._trading_currency_df: pd.Series = pd.Series(
            {inst.isin: inst.currency.value for inst in instruments}
        )

        # Year fractions
        self._standard_year_fractions: pd.Series = pd.Series(dtype=float)
        self._shifted_year_fractions: pd.Series = pd.Series(dtype=float)
        self._calculate_year_fractions()

        # Dati scaricati (inizializzati vuoti)
        self._dividends: pd.DataFrame = pd.DataFrame()
        self._adjustments_df: pd.DataFrame = pd.DataFrame()


    # ========================================================================
    # METODI PUBBLICI - Da implementare nelle subclass
    # ========================================================================

    @abstractmethod
    def download_data(self):
        """
        Scarica tutti i dati necessari per lo strumento.

        LE SUBCLASS CHIAMANO DIRETTAMENTE ProviderAdapter!

        Esempio (StockClass):
            def download_data(self):
                self._dividends = self._data_downloader.download_dividends(
                    self._isin_list,
                    self._relevant_dates,
                    self._bbg_codes_dict
                )
        """
        pass

    @abstractmethod
    def _get_daily_adjustments(self, day: dt.date) -> pd.Series:
        """
        Calcola aggiustamenti per un giorno specifico.

        Args:
            day: Data per cui calcolare gli aggiustamenti

        Returns:
            Serie con aggiustamenti per ogni ISIN
        """
        pass

    def get_adjustments(self) -> pd.DataFrame:
        """
        Calcola aggiustamenti per tutte le date.

        Returns:
            DataFrame con aggiustamenti (index=date, columns=ISIN)
        """
        if self._adjustments_df.empty:
            adjustments_list = []

            for day in self._relevant_dates:
                daily_adj = self._get_daily_adjustments(day)
                adjustments_list.append(daily_adj)

            self._adjustments_df = pd.DataFrame(adjustments_list, index=self._relevant_dates)

        return self._adjustments_df

    def get_fx_corrections(self) -> pd.DataFrame:
        """
        Calcola correzioni FX.

        Base implementation: ritorna 0 (nessuna correzione).
        Subclass possono override per implementare logica FX.

        Returns:
            DataFrame con correzioni FX (index=date, columns=ISIN)
        """
        if self._fx_corrections_df.empty:
            self._fx_corrections_df = pd.DataFrame(
                0.,
                index=self._relevant_dates,
                columns=self._isin_list
            )
        return self._fx_corrections_df

    def clean_returns(self, returns_df: pd.DataFrame, cumulative: bool = False) -> pd.DataFrame:
        """
        Pulisce ritorni applicando aggiustamenti.

        Args:
            returns_df: DataFrame con ritorni grezzi
            cumulative: Se True, applica correzioni cumulative

        Returns:
            DataFrame con ritorni puliti
        """
        # Calcola aggiustamenti se necessario
        adjustments = self.get_adjustments()
        fx_corrections = self.get_fx_corrections()

        # Filtra per ISIN di questo strumento
        returns_filtered = returns_df[self._isin_list]

        # Applica correzioni
        if cumulative:
            # Cumulative: somma gli aggiustamenti prima di applicare
            total_adjustments = adjustments + fx_corrections
            cumulative_adjustments = total_adjustments[::-1].cumsum()[::-1]
            cleaned = returns_filtered + cumulative_adjustments
        else:
            # Non-cumulative: applica aggiustamenti diretti
            cleaned = returns_filtered + adjustments + fx_corrections

        return cleaned

    def on_fx_update(self, fx_update: pd.Series):
        """
        Callback quando ci sono nuovi dati FX.

        Invalida cache FX corrections.

        Args:
            fx_update: Serie con nuovi spot FX
        """
        self._fx_corrections_df = pd.DataFrame()

    # ========================================================================
    # METODI UTILITY
    # ========================================================================

    def get_instrument(self, isin: str) -> Instrument:
        """
        Recupera Instrument per ISIN.

        Args:
            isin: ISIN dello strumento

        Returns:
            Instrument object

        Raises:
            KeyError: Se ISIN non trovato
        """
        return self._instruments[isin]

    def _calculate_year_fractions(self):
        """
        Calcola year fractions per tutte le date.

        - Standard: frazione anno da data precedente a data corrente
        - Shifted: considera settlement (T+1, T+2)
        """
        self._standard_year_fractions = pd.Series(0., index=self._relevant_dates)
        self._shifted_year_fractions = pd.Series(0., index=self._relevant_dates)

        for i, day in enumerate(self._relevant_dates):
            if i == 0:
                continue

            prev_day = self._relevant_dates[i - 1]

            # Standard year fraction
            self._standard_year_fractions.loc[day] = calculate_year_fraction(prev_day, day)

            # Shifted year fraction (considera settlement)
            # TODO: Implementare logica settlement shift
            # Per ora usa standard
            self._shifted_year_fractions.loc[day] = self._standard_year_fractions.loc[day]

    def _align_dataframe(self, data: pd.DataFrame, name: str) -> pd.DataFrame:
        """
        Crea DataFrame allineato a relevant_dates x ids, integrando data scaricati.

        Args:
            data: DataFrame scaricato (può essere None/empty)
            name: Nome del dato per logging

        Returns:
            DataFrame allineato con 0.0 come default
        """
        aligned = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)

        if data is not None and not data.empty:
            aligned.update(data)
            self._logger.debug(f"{name}: integrated {data.shape[0]} rows, {data.shape[1]} columns")
        else:
            self._logger.warning(f"{name}: no data available, using zeros")

        return aligned