"""
Implementazione dello strumento ETF per il calcolo dei ritorni aggiustati.
Rifattorizzazione leggera: stessa API pubblica, codice interno più chiaro.
"""
import datetime as dt
import logging
from typing import List
from collections import Counter
import pandas as pd

from bshdata.analytics.adjustments.base_instrument_class import BaseInstrumentClassMeta
from bshdata.core.instruments.instruments import Instrument, EtfInstrument

logger = logging.getLogger(__name__)


class ETFClass(BaseInstrumentClassMeta):
    """
    Strumento ETF - gestisce il calcolo dei ritorni aggiustati per ETF.

    Mantiene la stessa API pubblica del codice originale ma con:
      - meno ripetizioni
      - logging coerente (self._logger)
      - fallback espliciti e tracciabili
      - correzioni a bug evidenti
    """

    def __init__(
        self,
        instruments: List[Instrument],
        data_downloader,
        relevant_dates: List[dt.date],
        settlement_type: pd.Series,
        etf_coverage_threshold: float = 0.3,
    ):
        # validation: tutti EtfInstrument
        for inst in instruments:
            if not isinstance(inst, EtfInstrument):
                raise TypeError(
                    f"Expected EtfInstrument, got {type(inst).__name__} for {getattr(inst, 'isin', '<unknown>')}"
                )

        self.snipping_time = None
        # data containers (inizializzati vuoti)
        self._etf_data = pd.DataFrame()
        self._etf_ter = pd.DataFrame()
        self._etf_ytm = pd.DataFrame()
        self._etf_fx = pd.DataFrame()
        self._etf_fx_fwd = pd.DataFrame()
        self._etf_coverage_threshold = etf_coverage_threshold



        # FX-related
        self._fx_returns = pd.DataFrame()
        self._fx_fairvalues = pd.DataFrame()
        self._fx_fwd_prices = pd.DataFrame()

        # eredita e imposta _instruments, _isin_list, _relevant_dates, _data_downloader, _logger, year fractions etc.
        super().__init__(instruments, data_downloader, relevant_dates, settlement_type)

        self._ids = [i.id for i in self._instruments]
        # cache temporaneo per adjustments calcolati
        self._adjustments = pd.DataFrame()
        # FX corrections cache
        self._fx_corrections_df = pd.DataFrame()
        self._fx_fwd_corrections = pd.DataFrame()

    # ----------------------
    # Public API
    # ----------------------
    def get_adjustments(self) -> pd.DataFrame:
        """
        Calcola e ritorna DataFrame(index=relevant_dates, columns=isin) con tutti gli aggiustamenti.
        """
        # assicurati di avere metadata degli strumenti
        self._get_individual_instrument_data_if_needed()

        # scarica i dati necessari (metodi interni gestiscono fallback/log)
        try:
            self.download_data()
        except Exception as e:
            self._logger.exception("Error while downloading ETF supporting data: %s", e)
            # se il download fallisce, procediamo con quello che abbiamo (zero-filled)

        # assicurati strutture fondamentali esistano e siano reindicizzate
        self._ensure_core_frames()

        # crea correzioni FX (le funzioni si occupano di generare DataFrame zero se mancano dati)
        try:
            self._create_fx_corrections()
        except Exception as e:
            self._logger.exception("Error creating FX corrections; using zeros: %s", e)
            self._fx_corrections_df = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)

        try:
            self._create_fx_fwd_corrections()
        except Exception as e:
            self._logger.exception("Error creating FX forward corrections; using zeros: %s", e)
            self._fx_fwd_corrections = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)

        # build adjustments matrix in vectorized way: iterate dates but keep logic concise
        adjustments = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)

        for day in self._relevant_dates:
            try:
                daily = self._get_daily_adjustments(day)
            except Exception as e:
                self._logger.exception("Daily adjustments failed for %s: %s", day, e)
                daily = pd.Series(0.0, index=self._ids)

            # add fx corrections (already aligned)
            if not self._fx_corrections_df.empty and day in self._fx_corrections_df.index:
                daily = daily.add(self._fx_corrections_df.loc[day].reindex(self._ids).fillna(0.0), fill_value=0.0)

            if not self._fx_fwd_corrections.empty and day in self._fx_fwd_corrections.index:
                daily = daily.add(self._fx_fwd_corrections.loc[day].reindex(self._ids).fillna(0.0), fill_value=0.0)

            adjustments.loc[day] = daily

        self._adjustments = adjustments
        return adjustments

    def download_data(self, **kwargs):
        """Scarica i dataset principali (metodi interni gestiscono eccezioni e fallback)."""
        # ordine: dividendi, TER, YTM, FX composition, FX rates/forwards
        self._download_etf_dividends()
        self._download_ter()
        self._download_ytm()
        # FX composition potrebbe riempire _etf_fx e _etf_fx_fwd
        self._download_fx_composition(**kwargs)

    # ----------------------
    # Internal helpers
    # ----------------------
    def _ensure_core_frames(self):
        """Assicura che DataFrame principali esistano e siano reindicizzati correttamente."""
        # inizializzazioni con shape corretta se mancanti
        if getattr(self, "_dividends", None) is None or self._dividends is None:
            self._dividends = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
        else:
            self._dividends = self._dividends.reindex(index=self._relevant_dates, columns=self._ids, fill_value=0.0)

        if getattr(self, "_etf_ter", None) is None:
            self._etf_ter = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
        else:
            self._etf_ter = self._etf_ter.reindex(index=self._relevant_dates, columns=self._ids, fill_value=0.0)

        if getattr(self, "_etf_ytm", None) is None:
            self._etf_ytm = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
        else:
            self._etf_ytm = self._etf_ytm.reindex(index=self._relevant_dates, columns=self._ids, fill_value=0.0)

        # FX frames: may be empty (allowed)
        if getattr(self, "_etf_fx", None) is None:
            self._etf_fx = pd.DataFrame()
        if getattr(self, "_etf_fx_fwd", None) is None:
            self._etf_fx_fwd = pd.DataFrame()
        if getattr(self, "_fx_returns", None) is None:
            self._fx_returns = pd.DataFrame()
        if getattr(self, "_fx_fairvalues", None) is None:
            self._fx_fairvalues = pd.DataFrame()
        if getattr(self, "_fx_fwd_prices", None) is None:
            self._fx_fwd_prices = pd.DataFrame()

    def _get_daily_adjustments(self, day: dt.date) -> pd.Series:
        """
        Calcola gli aggiustamenti giornalieri per gli ETF secondo regole:
        + dividendi
        - TER * year_fraction (standard)
        - YTM * shifted_year_fraction
        Applica issuance mask (ETF non ancora emessi hanno 0).
        """
        # garantisci year-fractions presenti (ereditati da base; altrimenti fallback)
        if getattr(self, "_standard_year_fractions", None) is None or self._standard_year_fractions.empty:
            self._standard_year_fractions = pd.Series(1 / 252, index=self._relevant_dates)
        if getattr(self, "_shifted_year_fractions", None) is None or self._shifted_year_fractions.empty:
            self._shifted_year_fractions = pd.Series(1 / 252, index=self._relevant_dates)

        # base zero series
        daily = pd.Series(0.0, index=self._ids, dtype=float)

        # dividends (if day present)
        if not self._dividends.empty and day in self._dividends.index:
            daily = daily.add(self._dividends.loc[day].reindex(self._ids).fillna(0.0), fill_value=0.0)

        # TER pro-rata
        if not self._etf_ter.empty and day in self._etf_ter.index:
            ter_day = self._etf_ter.loc[day].reindex(self._ids).fillna(0.0)
            daily = daily.subtract(ter_day * self._standard_year_fractions.loc[day], fill_value=0.0)

        # YTM carry (shifted fractions)
        if not self._etf_ytm.empty and day in self._etf_ytm.index:
            ytm_day = self._etf_ytm.loc[day].reindex(self._ids).fillna(0.0)
            daily = daily.subtract(ytm_day * self._shifted_year_fractions.loc[day], fill_value=0.0)

        # issuance mask: zero per ETF non ancora emessi (ISSUE_DATE > day)
        if not self._etf_data.empty and "ISSUE_DATE" in self._etf_data.columns:
            # vectorized boolean: True if issued ON or BEFORE day
            issued_series = self._etf_data["ISSUE_DATE"].apply(lambda d: (d <= day) if pd.notnull(d) else False)
            issued_series = issued_series.reindex(self._ids).fillna(False)
            # set to zero where not issued
            not_issued = ~issued_series
            if not_issued.any():
                daily.loc[not_issued[not_issued].index] = 0.0

        return daily

    # ----------------------
    # FX corrections
    # ----------------------
    def get_fx_corrections(self) -> pd.DataFrame:
        """
        Restituisce DataFrame con correzioni FX giornaliere per ISIN.
        Se non possibile (dati mancanti) restituisce zeros DataFrame.
        """
        if isinstance(self._fx_corrections_df, pd.DataFrame) and not self._fx_corrections_df.empty:
            return self._fx_corrections_df

        # requisiti minimi
        if self._fx_returns.empty or self._etf_fx.empty:
            zeros = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
            self._fx_corrections_df = zeros
            return zeros

        # prodotto matriciale: (dates x currencies) dot (currencies x isins) -> dates x isins
        try:
            fx_corr = self._fx_returns.dot(self._etf_fx.T)
        except Exception as e:
            self._logger.exception("FX corrections matrix multiply failed: %s", e)
            self._fx_corrections_df = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
            return self._fx_corrections_df

        # trading currency adjustments (vectorized)
        if getattr(self, "_trading_currency_df", None) is not None and not self._trading_currency_df.empty:
            # _trading_currency_df: Series indexed by ISIN -> currency code
            trading_map = self._trading_currency_df.reindex(self._ids).fillna("EUR")
            # for each currency != EUR, subtract FX returns of that currency for instruments traded in that currency
            for ccy in trading_map.unique():
                if ccy == "EUR":
                    continue
                if ccy not in self._fx_returns.columns:
                    raise Exception(f"Trading currency {ccy} not supported. Missing FX return for {ccy}")
                mask = trading_map[trading_map == ccy].index.tolist()
                if mask:
                    fx_corr.loc[:, mask] = fx_corr.loc[:, mask].sub(self._fx_returns[ccy], axis=0)

        # issuance mask: azzero per ETF non emessi (vectorized)
        if not self._etf_data.empty and "ISSUE_DATE" in self._etf_data.columns:
            # build boolean DataFrame (dates x isins): True if issued
            issued_df = pd.DataFrame(
                {
                    isin: self._etf_data.loc[isin, "ISSUE_DATE"] <= pd.Series(self._relevant_dates, index=self._relevant_dates)
                    if isin in self._etf_data.index and pd.notnull(self._etf_data.loc[isin, "ISSUE_DATE"])
                    else False
                    for isin in self._ids
                },
                index=self._relevant_dates,
            )
            fx_corr = fx_corr.where(issued_df, other=0.0)

        self._fx_corrections_df = fx_corr.reindex(index=self._relevant_dates, columns=self._ids, fill_value=0.0)
        return self._fx_corrections_df

    def _create_fx_corrections(self):
        # compatibilità con chiamate precedenti
        self.get_fx_corrections()

    def _create_fx_fwd_corrections(self):
        """
        Calcola correzioni da FX forward in forma annualizzata.
        Se mancano dati, ritorna DataFrame di zeri.
        """
        if self._fx_fwd_prices.empty or self._fx_fairvalues.empty or self._etf_fx_fwd.empty:
            self._fx_fwd_corrections = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
            return self._fx_fwd_corrections

        try:
            # standardizza units: bp -> decimal annualized approximation
            fx_fwd_annualized = self._fx_fwd_prices * 12.0  # assume 1M quoted -> annualize
            fx_fwd_diff = fx_fwd_annualized / 1e4  # bp -> decimal
            fx_fwd_rates = fx_fwd_diff.div(self._fx_fairvalues.loc[fx_fwd_diff.index, fx_fwd_diff.columns])
            fx_fwd_corr = fx_fwd_rates.dot(self._etf_fx_fwd.T)
        except Exception as e:
            self._logger.exception("FX forward correction computation failed: %s", e)
            self._fx_fwd_corrections = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
            return self._fx_fwd_corrections

        # ensure all ISIN columns exist
        for col in self._ids:
            if col not in fx_fwd_corr.columns:
                fx_fwd_corr[col] = 0.0

        fx_fwd_corr = fx_fwd_corr.reindex(index=self._relevant_dates, columns=self._ids, fill_value=0.0)
        self._fx_fwd_corrections = fx_fwd_corr
        return fx_fwd_corr

    # ----------------------
    # Downloads (wrapped with logs and safer fallback)
    # ----------------------
    def _get_individual_instrument_data_if_needed(self):
        """Scarica metadata ETF solo se vuoto."""
        if self._etf_data.empty:
            try:
                self._check_duplicates(self._ids)
            except Exception as e:
                self._logger.exception("Failed to download or validate ETF metadata: %s", e)
                # keep _etf_data empty (means issuance checks will be skipped)

    def _download_etf_dividends(self):
        self._logger.info("Downloading ETF dividends...")
        ids = [i.id for i in self._instruments]
        try:
            self._dividends = self._data_downloader.download_dividends(isin_list=ids,
                                                                       relevant_dates=self._relevant_dates,
                                                                       instrument_type="ETP").reindex(index=self._relevant_dates, columns=ids, fill_value=0.0)
        except NotImplementedError:
            self._logger.info("Dividends download not implemented; using zeros.")
            self._dividends = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
        except Exception:
            self._logger.exception("Dividends download failed; using zeros.")
            self._dividends = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
        self._logger.debug("ETF dividends download complete.")

    def _download_ter(self):
        self._logger.info("Downloading ETF TER...")
        try:
            ter = self._data_downloader.download_etf_ter(self._ids, self._relevant_dates)
            if ter is None or ter.empty:
                self._etf_ter = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
            else:
                # ter may be series indexed by ISIN or df; normalize to df with dates index
                if isinstance(ter, pd.DataFrame) and len(ter.columns) == 1:
                    ter = ter["TER"]
                if isinstance(ter, pd.Series):
                    # Replico la Series per tutte le date
                    ter_df = pd.DataFrame(
                        [ter.values] * len(self._relevant_dates),
                        index=self._relevant_dates,
                        columns=ter.index
                    )
                    self._etf_ter = ter_df
                else:
                    self._etf_ter = ter.reindex(index=self._relevant_dates, columns=self._ids, fill_value=0.0)
        except NotImplementedError:
            self._logger.info("TER download not implemented; using zeros.")
            self._etf_ter = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
        except Exception as e:
            self._logger.exception("TER download failed; using zeros.", exc_info=e)
            self._etf_ter = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
        self._logger.debug("ETF TER download complete.")

    def _download_ytm(self):
        self._logger.info("Downloading ETF YTM...")
        self._instruments: List[EtfInstrument]
        try:
            fi_instruments = [i.id for i in self._instruments if i.underlying_type == "FIXED INCOME"]
            if fi_instruments:
                ytm_data = self._data_downloader.download_etf_ytm(fi_instruments, self._relevant_dates,
                                                                  self._etf_coverage_threshold)
                if ytm_data is not None and not ytm_data.empty:
                    # align into full matrix with zero default
                    all_cols_df = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
                    all_cols_df.update(ytm_data)
                    self._etf_ytm = all_cols_df
                else:
                    self._etf_ytm = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
            else:
                self._etf_ytm = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
        except NotImplementedError:
            self._logger.info("YTM download not implemented; using zeros.")
            self._etf_ytm = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)
        except Exception as e:
            self._logger.exception("YTM download failed; using zeros.", exc_info=e)
            self._etf_ytm = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)

        self._logger.debug("ETF YTM download complete.")

    def _download_fx_composition(self, **kwargs):
        self._logger.info("Downloading ETF FX composition...")
        try:
            fx = self._data_downloader.download_etf_fx_composition(self._ids, self._relevant_dates)
            # expect dict {'fx': df, 'fxfwd': df}
            self._etf_fx = fx.get("fx", pd.DataFrame())
            self._etf_fx_fwd = fx.get("fxfwd", pd.DataFrame())
        except NotImplementedError:
            self._logger.info("FX composition not implemented; skipping.")
            self._etf_fx = pd.DataFrame()
            self._etf_fx_fwd = pd.DataFrame()
        except Exception:
            self._logger.exception("FX composition download failed; skipping.")
            self._etf_fx = pd.DataFrame()
            self._etf_fx_fwd = pd.DataFrame()

        # compute fx rates and fwd prices if exposures exist
        fx_pairs = list(self._etf_fx.columns) if not self._etf_fx.empty else []
        if fx_pairs:
            try:
                fx_spots = self._download_fx(fx_pairs, snipping_time=kwargs.get("snipping_time", dt.time(17)))
                self._fx_returns = self._calculate_fx_returns(fx_spots)
            except Exception:
                self._logger.exception("FX rates download failed; leaving fx_returns empty.")
                self._fx_returns = pd.DataFrame()

        # forward prices for currency pairs (pass list of currencies/pairs)
        fxfwd_pairs = list(self._etf_fx_fwd.columns) if not self._etf_fx_fwd.empty else []
        if fxfwd_pairs:
            try:
                # assign result into self._fx_fwd_prices (important: was bug earlier)
                start, end = self._relevant_dates[0], self._relevant_dates[-1]
                self._fx_fwd_prices = self._data_downloader.download_fxfwrd(fxfwd_pairs, start, end, self.snipping_time)
                # fairvalues may come from same source or another API; leave as is if not present
            except Exception:
                self._logger.exception("FX forward prices download failed; leaving fx_fwd_prices empty.")
                self._fx_fwd_prices = pd.DataFrame()

        self._logger.debug("ETF FX composition download complete.")

    def _download_fx(self, fx_cols, snipping_time):
        return self._data_downloader.download_fx(fx_cols, self._relevant_dates, snipping_time)

    # ----------------------
    # Utilities
    # ----------------------
    def _check_duplicates(self, isin_list: List[str]):
        duplicates = self._find_duplicates(isin_list)
        if duplicates:
            raise Exception(f"The following ETFs are repeated: {duplicates}")

    @staticmethod
    def _find_duplicates(lst: List[str]) -> List[str]:
        return [item for item, count in Counter(lst).items() if count > 1]

    def _calculate_fx_returns(self, fx: pd.DataFrame) -> pd.DataFrame:
        if fx is None or fx.empty:
            return pd.DataFrame()
        return fx.pct_change().dropna(how="all")

