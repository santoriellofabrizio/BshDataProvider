import datetime as dt
import logging
from typing import List
import pandas as pd
from collections import Counter

from bshdata.analytics.adjustments.base_instrument_class import BaseInstrumentClassMeta
from bshdata.core.instruments.instruments import CDXIndexInstrument

logger = logging.getLogger(__name__)


class CDXClass(BaseInstrumentClassMeta):
    """
    Implementazione dei CDX per il calcolo degli adjusted returns,
    conforme all'architettura BSH (identica a FutureClass).

    Logica principale:
      - scarico fair values dei CDX
      - calcolo carry = fairvalue * (1 / TTM * 365) / 1e4
      - daily adjustments = carry * standard_year_fraction
    """

    def __init__(
        self,
        instruments: List[CDXIndexInstrument],
        data_downloader,
        relevant_dates: List[dt.date],
        settlement_type: pd.Series,
    ):

        # Validazione tipo
        for inst in instruments:
            if not isinstance(inst, CDXIndexInstrument):
                raise TypeError(
                    f"Expected CDXInstrument, got {type(inst).__name__} "
                    f"for {getattr(inst, 'isin', '<unknown>')}"
                )

        # containers
        self._cdx_data = pd.DataFrame()
        self._cdx_fairvalues = pd.DataFrame()
        self._cdx_carry = pd.DataFrame()

        super().__init__(instruments, data_downloader, relevant_dates, settlement_type)

        self._adjustments = pd.DataFrame()

    # ======================================================================
    # IDs helper
    # ======================================================================
    @property
    def _ids(self) -> List[str]:
        return [i.id for i in self._instruments]

    # ======================================================================
    # PUBLIC API
    # ======================================================================
    def get_adjustments(self) -> pd.DataFrame:
        """Restituisce il DataFrame degli adjustment giornalieri."""
        try:
            self.download_data()
        except Exception as e:
            self._logger.exception("Error downloading CDX data: %s", e)

        adj = pd.DataFrame(0.0, index=self._relevant_dates, columns=self._ids)

        for day in self._relevant_dates:
            try:
                daily = self._get_daily_adjustments(day)
            except Exception as e:
                self._logger.exception("Daily CDX adjustment failed for %s: %s", day, e)
                daily = pd.Series(0.0, index=self._ids)

            adj.loc[day] = daily

        self._adjustments = adj
        return adj

    # ======================================================================
    # DOWNLOAD
    # ======================================================================
    def download_data(self):
        self._download_cdx_prices()
        self._download_additional_info()

    def _download_additional_info(self):
        """Scarica metadati CDX (tenor, ecc)."""
        try:
            self._cdx_data = self._data_downloader.get_cdx_additional_data(self._ids)
            self._check_cdx_metadata(self._cdx_data)
        except Exception as e:
            self._logger.exception("CDX metadata download failed: %s", e)
            self._cdx_data = pd.DataFrame()

    def _download_cdx_prices(self):
        self._logger.info("Downloading CDX fair values...")

        try:
            fv = self._data_downloader.download_cdx_prices(
                self._ids, self._relevant_dates
            )

            self._cdx_fairvalues = self._align_dataframe(fv, "FairValues")
            self._create_carry_corrections()

        except Exception as e:
            self._logger.exception("CDX fair values download failed: %s", e)
            self._cdx_fairvalues = self._align_dataframe(None, "FairValues")

    # ======================================================================
    # DAILY ADJUSTMENTS
    # ======================================================================
    def _get_daily_adjustments(self, day: dt.date) -> pd.Series:
        """
        Regola CDX:
            adjustment = carry * standard_year_fraction
        """
        yf = self._standard_year_fractions.loc[day]

        out = pd.Series(0.0, index=self._ids)

        if not self._cdx_carry.empty:
            out += self._cdx_carry.loc[day].reindex(self._ids, fill_value=0.0) * yf

        return out

    # ======================================================================
    # CARRY LOGIC
    # ======================================================================
    def _create_carry_corrections(self):
        self._cdx_carry = pd.DataFrame(
            0.0, index=self._relevant_dates, columns=self._ids
        )

        for idx, day in enumerate(self._relevant_dates):
            ttm = self._get_cdx_time_to_maturity(day)
            corr = 1 / ttm * 365

            fv = self._cdx_fairvalues.iloc[idx].reindex(self._ids, fill_value=0.0)

            self._cdx_carry.loc[day] = corr * fv / 1e4

    # ======================================================================
    # CHECKING
    # ======================================================================
    @staticmethod
    def _check_cdx_metadata(df: pd.DataFrame):
        if df is None or df.empty:
            return

        # check duplicate codes
        if "BBG_CODE" in df.columns:
            counts = Counter(df["BBG_CODE"])
            repeats = [k for k, v in counts.items() if v > 1]
            if repeats:
                raise ValueError(f"Duplicate CDX tickers: {repeats}")

        # check tenor
        if "TENOR" in df.columns:
            implemented = ["5Y"]
            for t in df["TENOR"].dropna().unique():
                if t not in implemented:
                    raise ValueError(f"CDX tenor {t} is not implemented")

    # ======================================================================
    # TTM LOGIC
    # ======================================================================
    @staticmethod
    def _get_cdx_time_to_maturity(day: dt.date) -> float:
        year = day.year
        m20 = dt.date(year, 3, 20)
        s20 = dt.date(year, 9, 20)

        if day < m20:
            creation = dt.date(year - 1, 9, 20)
        elif day < s20:
            creation = m20
        else:
            creation = s20

        return 365 * 5 - (day - creation).days
