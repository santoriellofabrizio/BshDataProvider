import logging
from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any, Set

from bshdata.core.requests.requests import BaseRequest
from bshdata.providers.oracle.query_oracle import QueryOracle

logger = logging.getLogger(__name__)


class Handler(ABC):
    def __init__(self):
        self._next: Optional['Handler'] = None

    def set_next(self, handler: 'Handler') -> 'Handler':
        self._next = handler
        return handler

    def handle(self, requests: List[Any], query: QueryOracle) -> Dict[str, Any]:
        """
        Gestisce una LISTA di requests.
        Ogni handler elabora SOLO i fields che sa gestire, il resto va al next.

        SUPPORTA 2 FORMATI DI OUTPUT DA process():
            A) { FIELD: { sub: value } }
            B) { sub: { FIELD: value } }
        """
        can_process = []
        remaining = []

        # 1) Split requests gestibili / non gestibili
        for req in requests:
            if self.can_handle(req):
                can_process.append(req)
            else:
                remaining.append(req)

        results = {}
        downstream_requests = []

        # 2) Processa IN BATCH le richieste compatibili
        if can_process:
            # Raccogli tutti i field richiesti
            requested_fields = {
                f.upper()
                for req in can_process
                for f in req.fields
            }

            raw_out = self.process(can_process, query) or {}
            out = self._normalize_output(raw_out, requested_fields)

            # 🆕 Garantisci presenza di tutti gli strumenti
            out = self._ensure_all_instruments_present(
                out,
                can_process,
                requested_fields
            )
            # out normalizzato: { FIELD: { sub: value } }
            for req in can_process:
                req_id = req.instrument.id
                sub = req.subscription or req.instrument.isin or req.instrument.ticker
                requested_fields = {f.upper() for f in req.fields}

                results.setdefault(req_id, {})
                handled_fields = set()

                for field, submap in out.items():
                    ufield = field.upper()
                    if ufield in requested_fields:
                        val = submap.get(sub)
                        results[req_id][ufield] = val
                        handled_fields.add(ufield)

                missing = requested_fields - handled_fields
                if missing:
                    req.field = list(missing)
                    downstream_requests.append(req)

        # 3) Aggiungi requests non gestibili
        if remaining:
            downstream_requests.extend(remaining)

        # 4) Downstream
        if downstream_requests and self._next:
            down = self._next.handle(downstream_requests, query)
            for req_id, data in down.items():
                results.setdefault(req_id, {}).update(data)

        return results

    def _normalize_output(self, out: Dict[str, Any], requested_fields: set) -> Dict[str, Dict[str, Any]]:
        """
        Normalizza in formato A:
            { FIELD: { sub: value } }

        Distinguendo i formati usando SOLO le chiavi top-level.
        """

        if not out:
            return {}

        keys = list(out.keys())

        # se almeno una chiave è un field richiesto → FORMATO A
        if any(k.upper() in requested_fields for k in keys):
            return out  # già del tipo {FIELD: {sub: value}}

        # altrimenti → FORMATO B
        # { sub: {field: value} } → {field: {sub: value}}
        normalized = {}

        for sub, fieldmap in out.items():
            if isinstance(fieldmap, dict):
                for field, value in fieldmap.items():
                    normalized.setdefault(field.upper(), {})[sub] = value
            else:
                pass
        return normalized

    @abstractmethod
    def can_handle(self, req) -> bool:
        pass

    @abstractmethod
    def process(
            self,
            requests: List[BaseRequest],
            query: QueryOracle
    ) -> Dict[str, Dict[str, Any]]:
        """
        Gestisce field statici ETF.

        Returns:
            {isin: {field: value, ...}}
            Garantisce presenza di tutti gli ISIN richiesti.
        """
        isins = [req.instrument.isin for req in requests]
        fields = set(f for r in requests for f in r.fields)

        # 🆕 Inizializza con tutti gli ISIN
        result = {isin: {} for isin in isins}

        # TER
        if "TER" in fields:
            ter_data = query.get_etf_ter(isins)
            for isin, data in ter_data.items():
                if isin in result:
                    result[isin].update(data)  # 🆕 update invece di sovrascrivere

        # MARKETS
        if "MARKETS" in fields:
            markets_data = query.get_etf_markets(isins)
            # markets_data è List[Dict], va trasformato
            markets_by_isin = {}
            for item in markets_data:
                isin = item.get("isin") or item.get("ISIN")
                if isin:
                    markets_by_isin.setdefault(isin, []).append(item)

            for isin, markets_list in markets_by_isin.items():
                if isin in result:
                    result[isin]["MARKETS"] = markets_list

        # Altri field statici
        other = fields - {"TER", "MARKETS"}
        if other:
            static_data = query.get_etf_static_field(isins, subset=list(other))
            for isin, data in static_data.items():
                if isin in result:
                    result[isin].update(data)  # 🆕 update invece di sovrascrivere

        # 🆕 Verifica completezza: aggiungi None per field mancanti
        for isin in isins:
            missing = fields - set(result[isin].keys())
            for field in missing:
                result[isin][field] = None
                logger.debug(f"Field '{field}' not found for {isin}, set to None")

        return result


    def _ensure_all_instruments_present(
            self,
            result: Dict[str, Dict[str, Any]],
            requests: List[Any],
            requested_fields: Set[str]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Garantisce che tutti gli strumenti richiesti siano presenti nei risultati,
        anche se con field = None.

        Questo è un safety net: se un handler dimentica di includere uno strumento
        senza dati, questo metodo lo aggiunge automaticamente.

        Args:
            result: Risultato grezzo dalla query/handler
            requests: Lista di richieste originali
            requested_fields: Set di field richiesti

        Returns:
            Result normalizzato con tutti gli strumenti presenti

        Example:
            Input result: {"ETF1": {"TER": 0.5}}
            Input requests: [req1(ETF1), req2(ETF2)]
            Output: {"ETF1": {"TER": 0.5}, "ETF2": {"TER": None}}
        """
        for req in requests:
            instrument_id = req.instrument.id

            # Aggiungi strumento se mancante
            if instrument_id not in result:
                result[instrument_id] = {}
                logger.debug(f"Added missing instrument to results: {instrument_id}")

            # Aggiungi field mancanti con None
            for field in requested_fields:
                if field not in result[instrument_id]:
                    result[instrument_id][field] = None
                    logger.debug(f"Added missing field '{field}' for {instrument_id}")

        return result


class ReferenceFieldHandler(Handler, ABC):
    pass


class HistoricalFieldHandler(Handler, ABC):
    """
        Abstract base class for historical field handlers.
        Similar to Handler but designed for time-series data.
        """

    def set_next(self, handler: 'HistoricalFieldHandler') -> 'HistoricalFieldHandler':
        """Link the next handler in the chain."""
        self._next = handler
        return handler


class BulkFieldHandler(Handler, ABC):
    """
    Abstract base class for bulk field handlers.
    Handles large dataset requests.
    """

    def set_next(self, handler: 'BulkFieldHandler') -> 'BulkFieldHandler':
        """Link the next handler in the chain."""
        self._next = handler
        return handler


class GeneralHandler(Handler, ABC):
    """
    Base handler for general (global) field requests.

    General handlers process fields not tied to specific instruments,
    such as lookup tables, reference data, and global configurations.
    """

    def set_next(self, handler: 'GeneralHandler') -> 'GeneralHandler':
        """Link the next handler in the chain."""
        self._next = handler
        return handler
