from typing import List, Any, Dict, Callable

from bshdata.core.enums.instrument_types import InstrumentType
from bshdata.core.holidays.holiday_manager import HolidayManager
from bshdata.core.requests.requests import  BaseStaticRequest
from bshdata.providers.timescale.handlers.base_handlers import TimescaleHandler
from bshdata.providers.timescale.query_timescale import QueryTimeScale


class CarryHandler(TimescaleHandler):

    def process(self, requests: List[Any], query: QueryTimeScale) -> Dict[str, Any]:

        query.overnight_financing_rate_for_currency()

    def can_handle(self, req: BaseStaticRequest) -> bool:
        return "CARRY" in [f.upper() for f in req.fields]

