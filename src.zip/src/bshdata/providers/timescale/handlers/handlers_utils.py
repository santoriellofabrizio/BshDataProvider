import pandas as pd


def _freq_to_seconds(freq: str) -> int:
    # es: "5m" → 300
    freq = freq.lower()
    if freq.endswith("m"):
        return int(freq[:-1]) * 60
    if freq.endswith("s"):
        return int(freq[:-1])
    raise ValueError(f"Unsupported frequency: {freq}")


def _normalize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return df

    rename_map = {
        "datetime_sampled": "timestamp",
        "datetime": "timestamp",
        "currency_pair": "isin",
        "bid_px_lev_0": "bid",
        "ask_px_lev_0": "ask",
        "mid_price": "mid",
        "bid_price": "bid",
        "ask_price": "ask",
    }

    # Rename campi
    df = df.rename(columns={c: rename_map.get(c, c) for c in df.columns})

    cols = set(df.columns)

    # Ricostruzione mid
    if "mid" not in cols and {"bid", "ask"} <= cols:
        df["mid"] = (df["bid"] + df["ask"]) / 2

    # spread = (ask - bid) / 2   ← questa è la TUA formula originale
    if "spread" not in cols and {"bid", "ask"} <= cols:
        df["spread"] = (df["ask"] - df["bid"]) / 2

    # spread_pct = (ask - bid) / (ask + bid)
    if "spread_pct" not in cols and {"bid", "ask"} <= cols:
        df["spread_pct"] = (df["ask"] - df["bid"]) / (df["ask"] + df["bid"]).replace(0, pd.NA)

    # Costruzione date da timestamp
    if "timestamp" in df.columns and "date" not in df.columns:
        df["date"] = pd.to_datetime(df["timestamp"]).dt.date

    return df

def _build_results(
        df: pd.DataFrame,
        requests: list,
        fields: list[str],
        is_daily: bool,
        business_days,
        fstart,
        fend,
) -> dict:
    """
    Ricostruisce il dizionario dei risultati coerenti per ogni strumento.

    Output finale:
    {
        "IE00B4L5Y983": {
            "PX_LAST": {date1: val1, date2: val2, ...},
            "PX_OPEN": {date1: val1, ...},
        },
        ...
    }
    """
    results: dict[str, dict[str, dict]] = {}
    ref_index = (
        pd.Index(business_days) if is_daily else pd.DatetimeIndex([fstart, fend])
    )

    # Cicla ogni request (instrument)
    for req in requests:
        isin = req.instrument.isin or req.instrument.id
        if not df.empty:
            sub_df = df[df["isin"] == req.subscription]
            if sub_df.empty:
                # Se non ci sono dati per quell’ISIN → serie di None
                results[req.instrument.id] = {
                    f: pd.Series([None] * len(ref_index), index=ref_index).to_dict()
                    for f in fields
                }
                continue

            # Costruisce l’indice temporale corretto
            idx = (
                pd.to_datetime(sub_df["date"]).dt.date
                if is_daily
                else pd.to_datetime(sub_df["timestamp"])
            )

            # Crea dizionario field → {timestamp: valore medio per giorno}
            if is_daily:
                results[req.instrument.id] = {
                    f: pd.Series(sub_df[f].values, index=idx)
                    .groupby(level=0)
                    .mean()
                    .reindex(ref_index)
                    .to_dict()
                    for f in fields
                    if f in sub_df.columns
                }
            else:
                results[req.instrument.id] = {
                    f: pd.Series(sub_df[f].values, index=idx).loc[fstart: fend]
                    .groupby(level=0)
                    .mean()
                    .reindex(ref_index)
                    .to_dict()
                    for f in fields
                    if f in sub_df.columns
                }

    return results