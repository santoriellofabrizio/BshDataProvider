from bshdata.providers.timescale.handlers.base_handlers import TimescaleHandler


class BondHandler(TimescaleHandler):
    def can_handle(self, req):
        return req.instrument.type.upper() == "BOND"

    def process(self, requests, query):
        raise NotImplementedError  # TODO implement
