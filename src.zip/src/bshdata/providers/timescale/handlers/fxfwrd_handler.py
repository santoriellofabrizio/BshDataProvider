from bshdata.providers.timescale.handlers.base_handlers import TimescaleHandler


class FXFwdHandler(TimescaleHandler):
    def can_handle(self, req):
        return req.instrument.type.upper() == "FXFWD"

    def process(self, requests, query):
        raise NotImplemented # TODO implement
