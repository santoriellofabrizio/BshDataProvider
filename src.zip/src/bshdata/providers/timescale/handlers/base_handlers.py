import logging
from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any

import pandas as pd

from bshdata.core.holidays.holiday_manager import HolidayManager
# esattamente come Oracle
from bshdata.core.requests.requests import BaseRequest
from bshdata.providers.timescale.query_timescale import QueryTimeScale

logger = logging.getLogger(__name__)


class TimescaleHandler(ABC):
    """
    Versione Timescale perfettamente speculare al sistema Oracle.
    Stessa logica, stesso comportamento, stesso formato di output.
    """
    holiday_manager = HolidayManager()

    def __init__(self):
        self._next: Optional['TimescaleHandler'] = None

    def set_next(self, handler: 'TimescaleHandler') -> 'TimescaleHandler':
        self._next = handler
        return handler

    # ----------------------------------------------------------------------
    # ENTRY POINT IDENTICO A ORACLE
    # ----------------------------------------------------------------------
    def handle(self, requests: List[Any], query: QueryTimeScale) -> Dict[str, Any]:

        can_process = []
        remaining = []

        # 1) Split richieste gestibili / non gestibili
        for req in requests:
            if self.can_handle(req):
                can_process.append(req)
            else:
                remaining.append(req)

        results = {}
        downstream_requests = []

        # 2) Batch process delle richieste compatibili
        if can_process:
            results.update(self.process(can_process, query) or {})

        if remaining:
            downstream_requests.extend(remaining)

        # 4) Passa al prossimo handler Timescale
        if downstream_requests and self._next:
            downstream_out = self._next.handle(downstream_requests, query)

            for req_id, data in downstream_out.items():
                results.setdefault(req_id, {}).update(data)

        return results
    # ----------------------------------------------------------------------
    @abstractmethod
    def can_handle(self, req: BaseRequest) -> bool:
        pass

    # ----------------------------------------------------------------------
    @abstractmethod
    def process(self, requests: List[Any], query: QueryTimeScale) -> Dict[str, Any]:
        """
        Deve restituire uno dei due formati:
            A) { FIELD: { sub: value } }
            B) { sub: { FIELD: value } }
        """
        pass
