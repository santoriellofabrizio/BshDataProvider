from typing import List


from bshdata.core.base_classes.base_fetcher import BaseMarketFetcher
from bshdata.core.requests.requests import BaseMarketRequest
from bshdata.providers.timescale.handlers.bond_handler import BondHandler
from bshdata.providers.timescale.handlers.equity_handler import EquityHandler
from bshdata.providers.timescale.handlers.fallback_handler import FallbackHandler
from bshdata.providers.timescale.handlers.future_handler import FutureHandler
from bshdata.providers.timescale.handlers.fx_handler import FXHandler
from bshdata.providers.timescale.handlers.fxfwrd_handler import FXFwdHandler
from bshdata.providers.timescale.handlers.index_handler import IndexHandler
from bshdata.providers.timescale.query_timescale import QueryTimeScale


class TimescaleMarketFetcher(BaseMarketFetcher):

    def __init__(self, query_ts: QueryTimeScale, show_progress=True):
        super().__init__(show_progress)
        self.query_ts = query_ts

        # COSTRUISCO LA CHAIN (ordine logico)
        first = EquityHandler()
        first.set_next(FXHandler()) \
            .set_next(FutureHandler()) \
            .set_next(BondHandler()) \
            .set_next(FXFwdHandler()) \
            .set_next(IndexHandler()) \
            .set_next(FallbackHandler()) \

        self.chain = first

    def fetch(self, requests: List[BaseMarketRequest]):
        return self.chain.handle(requests, self.query_ts)
