

__all__ = [
    # ... existing exports ...
    "RequestState",
    "infer_state_from_result",
]

from bshdata.core.enums.request_state import RequestState