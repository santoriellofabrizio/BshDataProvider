"""
request_status.py - Value Object per lo stato di una richiesta.

Rappresenta lo stato immutabile di una singola richiesta in un momento specifico.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Set, Dict, Any

from bshdata.core.enums.request_state import RequestState, infer_state_from_result
from bshdata.core.requests.requests import BaseRequest


@dataclass(frozen=True)
class RequestStatus:
    """
    Value Object immutabile che rappresenta lo stato di una richiesta.

    Attributes:
        request: Richiesta originale
        state: Stato corrente (RequestState enum)
        fields_requested: Set di field richiesti
        fields_received: Set di field ricevuti con dati validi (non None)
        timestamp: Momento di creazione dello status
        error: Eventuale eccezione catturata
        provider: Nome del provider che ha gestito la richiesta
        metadata: Dizionario per dati aggiuntivi custom

    Example:
        >>> status = RequestStatus(
        ...     request=my_request,
        ...     state=RequestState.COMPLETE,
        ...     fields_requested={"TER", "DESCRIPTION"},
        ...     fields_received={"TER", "DESCRIPTION"}
        ... )
        >>> status.is_complete
        True
        >>> status.completion_rate
        1.0
    """

    request: BaseRequest
    state: RequestState
    fields_requested: Set[str]
    fields_received: Set[str]
    timestamp: datetime = field(default_factory=datetime.now)
    error: Optional[Exception] = None
    provider: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validazioni post-inizializzazione."""
        # Converti a set se necessario
        if not isinstance(self.fields_requested, set):
            object.__setattr__(self, 'fields_requested', set(self.fields_requested))
        if not isinstance(self.fields_received, set):
            object.__setattr__(self, 'fields_received', set(self.fields_received))

        # Validazione: fields_received deve essere subset di fields_requested
        if not self.fields_received.issubset(self.fields_requested):
            extra = self.fields_received - self.fields_requested
            raise ValueError(
                f"Received fields contain unexpected items: {extra}. "
                f"Expected only: {self.fields_requested}"
            )

    # ============================================================
    # Properties di Comodo
    # ============================================================

    @property
    def instrument_id(self) -> str:
        """ID dello strumento (ISIN, ticker, etc.)."""
        return self.request.instrument.id if self.request.instrument else "UNKNOWN"

    @property
    def request_id(self) -> str:
        """ID univoco della richiesta."""
        return self.request.request_id

    @property
    def is_complete(self) -> bool:
        """True se tutti i field sono stati ricevuti."""
        return self.state == RequestState.COMPLETE

    @property
    def is_partial(self) -> bool:
        """True se solo alcuni field sono stati ricevuti."""
        return self.state == RequestState.PARTIAL

    @property
    def is_failed(self) -> bool:
        """True se la richiesta è fallita completamente."""
        return self.state in (RequestState.FAILED, RequestState.TIMEOUT)

    @property
    def missing_fields(self) -> Set[str]:
        """Set di field richiesti ma non ricevuti."""
        return self.fields_requested - self.fields_received

    @property
    def completion_rate(self) -> float:
        """
        Percentuale di completamento (0.0 - 1.0).

        Returns:
            Rapporto tra field ricevuti e field richiesti
        """
        if not self.fields_requested:
            return 1.0
        return len(self.fields_received) / len(self.fields_requested)

    @property
    def has_error(self) -> bool:
        """True se c'è un errore associato."""
        return self.error is not None

    # ============================================================
    # Metodi di Utilità
    # ============================================================

    def to_dict(self) -> Dict[str, Any]:
        """
        Serializza lo status in un dizionario.

        Returns:
            Dizionario con tutti i dati dello status

        Example:
            >>> status.to_dict()
            {
                'request_id': 'IE00B4L5Y983:TER,DESCRIPTION',
                'instrument_id': 'IE00B4L5Y983',
                'state': 'complete',
                'fields_requested': ['TER', 'DESCRIPTION'],
                'fields_received': ['TER', 'DESCRIPTION'],
                'missing_fields': [],
                'completion_rate': 1.0,
                'timestamp': '2024-12-02T10:30:00',
                'provider': 'oracle',
                'has_error': False
            }
        """
        return {
            'request_id': self.request_id,
            'instrument_id': self.instrument_id,
            'state': self.state.value,
            'state_display': self.state.display_name,
            'fields_requested': sorted(self.fields_requested),
            'fields_received': sorted(self.fields_received),
            'missing_fields': sorted(self.missing_fields),
            'completion_rate': self.completion_rate,
            'timestamp': self.timestamp.isoformat(),
            'provider': self.provider,
            'has_error': self.has_error,
            'error_message': str(self.error) if self.error else None,
            'metadata': self.metadata,
        }

    def with_state(self, new_state: RequestState) -> 'RequestStatus':
        """
        Crea un nuovo RequestStatus con stato aggiornato.

        Args:
            new_state: Nuovo stato da applicare

        Returns:
            Nuovo RequestStatus immutabile con lo stato cambiato

        Raises:
            ValueError: Se la transizione non è valida

        Example:
            >>> new_status = status.with_state(RequestState.COMPLETE)
        """
        if not self.state.can_transition_to(new_state):
            raise ValueError(
                f"Invalid state transition: {self.state.name} -> {new_state.name}"
            )

        return RequestStatus(
            request=self.request,
            state=new_state,
            fields_requested=self.fields_requested,
            fields_received=self.fields_received,
            timestamp=datetime.now(),
            error=self.error,
            provider=self.provider,
            metadata=self.metadata,
        )

    def with_results(
            self,
            result_data: Dict[str, Any],
            error: Optional[Exception] = None
    ) -> 'RequestStatus':
        """
        Crea un nuovo RequestStatus aggiornato con i risultati ricevuti.

        Args:
            result_data: Dizionario con i dati ricevuti (formato: {field: value})
            error: Eventuale errore da registrare

        Returns:
            Nuovo RequestStatus con state e fields_received aggiornati

        Example:
            >>> result = {"TER": 0.005, "DESCRIPTION": None}
            >>> new_status = status.with_results(result)
            >>> new_status.fields_received
            {'TER'}  # DESCRIPTION è None quindi non conta
        """
        # Estrai field con dati validi (non None, non dict/list vuoti)
        fields_received = set()
        for field_name, field_value in result_data.items():
            if field_value is not None:
                # Se è dict/list, conta solo se non vuoto
                if isinstance(field_value, (dict, list)):
                    if field_value:  # Non vuoto
                        fields_received.add(field_name.upper())
                else:
                    fields_received.add(field_name.upper())

        # Inferisci nuovo stato
        new_state = infer_state_from_result(
            fields_requested=self.fields_requested,
            fields_received=fields_received,
            has_error=(error is not None)
        )

        return RequestStatus(
            request=self.request,
            state=new_state,
            fields_requested=self.fields_requested,
            fields_received=fields_received,
            timestamp=datetime.now(),
            error=error,
            provider=self.provider,
            metadata=self.metadata,
        )

    # ============================================================
    # Metodi Magic
    # ============================================================

    def __str__(self) -> str:
        """Human-readable representation."""
        return (
            f"RequestStatus({self.instrument_id}, "
            f"{self.state.display_name}, "
            f"{len(self.fields_received)}/{len(self.fields_requested)} fields)"
        )

    def __repr__(self) -> str:
        """Debug representation."""
        return (
            f"RequestStatus(request_id={self.request_id!r}, "
            f"state={self.state!r}, "
            f"completion={self.completion_rate:.1%})"
        )


# ============================================================
# Factory Functions
# ============================================================

def create_pending_status(
        request: BaseRequest,
        provider: Optional[str] = None
) -> RequestStatus:
    """
    Factory per creare uno status PENDING per una nuova richiesta.

    Args:
        request: Richiesta da tracciare
        provider: Nome del provider che gestirà la richiesta

    Returns:
        RequestStatus in stato PENDING

    Example:
        >>> status = create_pending_status(my_request, provider="oracle")
        >>> status.state
        RequestState.PENDING
    """
    fields = request.fields if isinstance(request.fields, list) else [request.fields]

    return RequestStatus(
        request=request,
        state=RequestState.PENDING,
        fields_requested=set(f.upper() for f in fields),
        fields_received=set(),
        provider=provider,
    )