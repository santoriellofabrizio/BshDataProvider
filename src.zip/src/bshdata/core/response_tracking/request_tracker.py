"""
request_tracker.py - Core logic per il tracking delle richieste.

Gestisce il ciclo di vita delle richieste in modo thread-safe,
permettendo di tracciare, aggiornare e interrogare lo stato di un batch.
"""

import threading
from datetime import datetime
from typing import Dict, List, Optional, Any, Set
import json
import logging

from bshdata.core.enums.request_state import RequestState
from bshdata.core.requests.requests import BaseRequest
from bshdata.core.response_tracking import RequestStatus, create_pending_status

logger = logging.getLogger(__name__)


class RequestTracker:
    """
    Tracker thread-safe per monitorare lo stato delle richieste.

    Gestisce il ciclo di vita completo delle richieste:
    - Registrazione iniziale (PENDING)
    - Aggiornamento con risultati (COMPLETE/PARTIAL/FAILED)
    - Query e aggregazioni
    - Export per audit

    Thread-safety garantita tramite RLock.

    Example:
        >>> request = BaseRequest()
        >>> tracker = RequestTracker()
        >>> tracker.track(request, provider="oracle")
        >>> tracker.update_with_result(request.request_id, {"TER": 0.005, "NAV": None})
        >>> status = tracker.get(request.request_id)
        >>> status.state
        RequestState.PARTIAL
    """

    def __init__(self, batch_id: Optional[str] = None):
        """
        Inizializza il tracker.

        Args:
            batch_id: Identificativo opzionale del batch
        """
        self._statuses: Dict[str, RequestStatus] = {}
        self._lock = threading.RLock()
        self._batch_id = batch_id or datetime.now().strftime("%Y%m%d_%H%M%S")
        self._created_at = datetime.now()

    # ============================================================
    # Tracking
    # ============================================================

    def track(
        self,
        request: BaseRequest,
        provider: Optional[str] = None
    ) -> RequestStatus:
        """
        Registra una nuova richiesta da tracciare.

        Args:
            request: Richiesta da tracciare
            provider: Nome del provider che gestirà la richiesta

        Returns:
            RequestStatus iniziale in stato PENDING

        Example:
            >>> status = tracker.track(my_request, provider="oracle")
            >>> status.state
            RequestState.PENDING
        """
        with self._lock:
            status = create_pending_status(request, provider)
            self._statuses[request.request_id] = status
            logger.debug(f"Tracked request: {request.request_id}")
            return status

    def track_many(
        self,
        requests: List[BaseRequest],
        provider: Optional[str] = None
    ) -> List[RequestStatus]:
        """
        Registra multiple richieste.

        Args:
            requests: Lista di richieste da tracciare
            provider: Provider comune per tutte le richieste

        Returns:
            Lista di RequestStatus iniziali
        """
        with self._lock:
            return [self.track(req, provider) for req in requests]

    # ============================================================
    # Update
    # ============================================================

    def update_with_result(
        self,
        request_id: str,
        result_data: Dict[str, Any],
        error: Optional[Exception] = None
    ) -> Optional[RequestStatus]:
        """
        Aggiorna lo stato di una richiesta con i risultati ricevuti.

        Args:
            request_id: ID della richiesta
            result_data: Dizionario con i dati ricevuti {field: value}
            error: Eventuale errore da registrare

        Returns:
            Nuovo RequestStatus aggiornato, o None se request_id non trovato

        Example:
            >>> tracker.update_with_result(
            ...     "IE00B4L5Y983:TER,NAV",
            ...     {"TER": 0.005, "NAV": None}
            ... )
        """
        with self._lock:
            if request_id not in self._statuses:
                logger.warning(f"Request not found for update: {request_id}")
                return None

            old_status = self._statuses[request_id]

            # Prima transizione a SENT se ancora PENDING
            if old_status.state == RequestState.PENDING:
                old_status = old_status.with_state(RequestState.SENT)

            # Poi aggiorna con i risultati
            new_status = old_status.with_results(result_data, error)
            self._statuses[request_id] = new_status

            logger.debug(
                f"Updated {request_id}: {old_status.state.name} -> {new_status.state.name} "
                f"({new_status.completion_rate:.0%})"
            )
            return new_status

    def mark_sent(self, request_id: str) -> Optional[RequestStatus]:
        """
        Marca una richiesta come inviata al provider.

        Args:
            request_id: ID della richiesta

        Returns:
            RequestStatus aggiornato, o None se non trovato
        """
        with self._lock:
            if request_id not in self._statuses:
                return None

            status = self._statuses[request_id]
            if status.state == RequestState.PENDING:
                new_status = status.with_state(RequestState.SENT)
                self._statuses[request_id] = new_status
                return new_status
            return status

    def mark_failed(
        self,
        request_id: str,
        error: Optional[Exception] = None
    ) -> Optional[RequestStatus]:
        """
        Marca una richiesta come fallita.

        Args:
            request_id: ID della richiesta
            error: Eccezione che ha causato il fallimento

        Returns:
            RequestStatus aggiornato, o None se non trovato
        """
        with self._lock:
            if request_id not in self._statuses:
                return None

            status = self._statuses[request_id]
            new_status = RequestStatus(
                request=status.request,
                state=RequestState.FAILED,
                fields_requested=status.fields_requested,
                fields_received=set(),
                error=error,
                provider=status.provider,
                metadata=status.metadata,
            )
            self._statuses[request_id] = new_status
            return new_status

    def mark_timeout(self, request_id: str) -> Optional[RequestStatus]:
        """
        Marca una richiesta come scaduta per timeout.

        Args:
            request_id: ID della richiesta

        Returns:
            RequestStatus aggiornato, o None se non trovato
        """
        with self._lock:
            if request_id not in self._statuses:
                return None

            status = self._statuses[request_id]
            new_status = RequestStatus(
                request=status.request,
                state=RequestState.TIMEOUT,
                fields_requested=status.fields_requested,
                fields_received=status.fields_received,
                error=TimeoutError("Request timed out"),
                provider=status.provider,
                metadata=status.metadata,
            )
            self._statuses[request_id] = new_status
            return new_status

    # ============================================================
    # Query
    # ============================================================

    def get(self, request_id: str) -> Optional[RequestStatus]:
        """
        Ottiene lo status di una richiesta specifica.

        Args:
            request_id: ID della richiesta

        Returns:
            RequestStatus o None se non trovato
        """
        with self._lock:
            return self._statuses.get(request_id)

    def get_all(self) -> List[RequestStatus]:
        """Ritorna tutti gli status tracciati."""
        with self._lock:
            return list(self._statuses.values())

    def get_by_state(self, state: RequestState) -> List[RequestStatus]:
        """
        Filtra richieste per stato.

        Args:
            state: Stato da filtrare

        Returns:
            Lista di RequestStatus con lo stato specificato
        """
        with self._lock:
            return [s for s in self._statuses.values() if s.state == state]

    def get_by_instrument(self, instrument_id: str) -> List[RequestStatus]:
        """
        Trova tutte le richieste per uno strumento.

        Args:
            instrument_id: ID dello strumento (ISIN, ticker, etc.)

        Returns:
            Lista di RequestStatus per lo strumento
        """
        with self._lock:
            return [
                s for s in self._statuses.values()
                if s.instrument_id == instrument_id
            ]

    def get_by_provider(self, provider: str) -> List[RequestStatus]:
        """
        Filtra richieste per provider.

        Args:
            provider: Nome del provider

        Returns:
            Lista di RequestStatus gestiti dal provider
        """
        with self._lock:
            return [
                s for s in self._statuses.values()
                if s.provider == provider
            ]

    # ============================================================
    # Aggregazioni
    # ============================================================

    @property
    def total(self) -> int:
        """Numero totale di richieste tracciate."""
        with self._lock:
            return len(self._statuses)

    @property
    def complete_count(self) -> int:
        """Numero di richieste completate."""
        return len(self.get_by_state(RequestState.COMPLETE))

    @property
    def partial_count(self) -> int:
        """Numero di richieste parziali."""
        return len(self.get_by_state(RequestState.PARTIAL))

    @property
    def failed_count(self) -> int:
        """Numero di richieste fallite."""
        return len(self.get_by_state(RequestState.FAILED))

    @property
    def success_rate(self) -> float:
        """Percentuale di successo (COMPLETE + PARTIAL)."""
        if self.total == 0:
            return 0.0
        return (self.complete_count + self.partial_count) / self.total

    def counts_by_state(self) -> Dict[str, int]:
        """
        Conteggio per ogni stato.

        Returns:
            Dizionario {state_name: count}
        """
        with self._lock:
            counts: Dict[str, int] = {}
            for status in self._statuses.values():
                state_name = status.state.value
                counts[state_name] = counts.get(state_name, 0) + 1
            return counts

    # ============================================================
    # Utility
    # ============================================================

    def clear(self) -> None:
        """Rimuove tutti gli status tracciati."""
        with self._lock:
            self._statuses.clear()
            logger.debug("Tracker cleared")

    def reset(self) -> None:
        """Reset completo del tracker con nuovo batch_id."""
        with self._lock:
            self._statuses.clear()
            self._batch_id = datetime.now().strftime("%Y%m%d_%H%M%S")
            self._created_at = datetime.now()

    def contains(self, request_id: str) -> bool:
        """Verifica se una richiesta è tracciata."""
        with self._lock:
            return request_id in self._statuses

    # ============================================================
    # Export
    # ============================================================

    def to_dict(self) -> Dict[str, Any]:
        """
        Serializza il tracker in un dizionario.

        Returns:
            Dizionario con metadata e tutti gli status
        """
        with self._lock:
            return {
                'batch_id': self._batch_id,
                'created_at': self._created_at.isoformat(),
                'total': self.total,
                'counts': self.counts_by_state(),
                'success_rate': self.success_rate,
                'statuses': {
                    req_id: status.to_dict()
                    for req_id, status in self._statuses.items()
                },
            }

    def export_json(self, filepath: str, indent: int = 2) -> None:
        """
        Esporta il tracker in un file JSON.

        Args:
            filepath: Percorso del file di output
            indent: Indentazione per pretty-print
        """
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=indent, default=str)
        logger.info(f"Tracker exported to {filepath}")

    # ============================================================
    # Display
    # ============================================================

    def format_summary(self) -> str:
        """Formatta un riepilogo testuale."""
        counts = self.counts_by_state()
        lines = [
            f"RequestTracker [{self._batch_id}]",
            f"  Total: {self.total}",
        ]
        for state in RequestState:
            count = counts.get(state.value, 0)
            if count > 0:
                lines.append(f"  {state.display_name}: {count}")
        lines.append(f"  Success rate: {self.success_rate:.1%}")
        return "\n".join(lines)

    def __str__(self) -> str:
        return self.format_summary()

    def __repr__(self) -> str:
        return f"RequestTracker(batch_id={self._batch_id!r}, total={self.total})"

    def __len__(self) -> int:
        return self.total

    def __contains__(self, request_id: str) -> bool:
        return self.contains(request_id)