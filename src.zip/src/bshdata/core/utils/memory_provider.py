import pandas as pd
from joblib import Memory
import os
import logging
from functools import wraps
import inspect

from bshdata.core.requests.requests import BaseRequest

# =============================================================
# CONFIGURAZIONE
# =============================================================

_cache_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "cache")
_memory_provider = None  # inizializzato lazy solo se serve

logger = logging.getLogger("cache")
ENABLE_CACHE = True


def _get_memory():
    """
    Crea (lazy) l'oggetto Memory solo quando serve davvero.
    Non crea la cartella cache se la cache è disabilitata.
    """
    global _memory_provider
    if _memory_provider is None:
        os.makedirs(_cache_dir, exist_ok=True)
        _memory_provider = Memory(_cache_dir, verbose=0)
    return _memory_provider


def enable_cache():
    global ENABLE_CACHE
    ENABLE_CACHE = True
    logger.info("Cache globally enabled")


def disable_cache():
    global ENABLE_CACHE
    ENABLE_CACHE = False
    logger.info("Cache globally disabled")

def set_cache_dir(path: str):
    """
    Set a custom directory for the joblib cache.
    Must be called **before** any cached function is used.

    Args:
        path (str): The directory to use for caching.
    """
    global _cache_dir, _memory_provider
    _cache_dir = os.path.abspath(path)
    _memory_provider = None  # force re-init on next use

    if ENABLE_CACHE:
        os.makedirs(_cache_dir, exist_ok=True)
        logger.info(f"Cache directory set to: {_cache_dir}")


# =============================================================
# DECORATORE
# =============================================================

def cache_bsh_data(func):
    """
    Decoratore robusto per caching:
    - ignora automaticamente 'self' e 'query_ts' se presenti nella firma
    - mantiene logging HIT/MISS
    - compatibile con metodi statici o di istanza
    - non crea la cartella cache se la cache è disabilitata
    """
    sig = inspect.signature(func)
    ignore_list = [name for name in ("self", "query_ts") if name in sig.parameters]

    @wraps(func)
    def wrapper(*args, **kwargs):
        if not ENABLE_CACHE:
            logger.info(f"[CACHE DISABLED] {func.__qualname__} — executing without cache")
            return func(*args, **kwargs)

        # inizializza Memory solo se serve
        memory_provider = _get_memory()
        cached_func = memory_provider.cache(func, ignore=ignore_list)

        try:
            is_cached = cached_func.check_call_in_cache(*args, **kwargs)
        except Exception:
            is_cached = False

        logger.info(
            f"[CACHE {'HIT' if is_cached else 'MISS'}] {func.__qualname__} "
            f"args={_safe_preview(args)} kwargs={_safe_preview(kwargs)}"
        )

        try:
            return cached_func(*args, **kwargs)
        except Exception as e:
            logger.warning(f"[CACHE ERROR] {func.__qualname__}: {e}")
            return func(*args, **kwargs)

    return wrapper


import json

def _safe_preview(x, maxlen=120):
    for x_ in x:
        if isinstance(x_, BaseRequest):
            return x.__repr__()

    try:
        # DataFrame
        if isinstance(x, pd.DataFrame):
            return f"<DataFrame shape={x.shape}>"

        # Lista
        if isinstance(x, (list, tuple)):
            return json.dumps(x[:3]) + ("..." if len(x) > 3 else "")

        # Dict
        if isinstance(x, dict):
            preview = {k: str(v)[:50] for k, v in list(x.items())[:5]}
            return json.dumps(preview) + ("..." if len(x) > 5 else "")

        # String or something simple
        s = str(x)
        return s if len(s) <= maxlen else s[:maxlen] + "..."

    except Exception:
        return "<unprintable>"
