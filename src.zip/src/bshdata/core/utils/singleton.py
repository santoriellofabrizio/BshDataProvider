class Singleton:
    """
    Base class per singleton semplici.
    Ogni sottoclasse avrà una sola istanza.
    """
    _instances = {}

    def __new__(cls, *args, **kwargs):
        # Impediamo l'uso diretto di Singleton
        if cls is Singleton:
            raise TypeError("Singleton base class cannot be instantiated directly")

        if cls not in cls._instances:
            instance = super().__new__(cls)
            cls._instances[cls] = instance
        return cls._instances[cls]
