from typing import Callable, List, Dict, Union
import pandas as pd
import math
import copy
import logging

from bshdata.core.utils.common import normalize_list

logger = logging.getLogger(__name__)


class RetryManager:
    """
    Gestore di retry intelligente per recupero dati finanziari con fallback.

    Questa classe implementa una strategia di recupero dati progressivo che:
    1. Identifica automaticamente dati mancanti (NaN) in DataFrame/Series
    2. Ottimizza le richieste successive richiedendo solo dati effettivamente mancanti
    3. Prova configurazioni alternative (fallback) fino a completamento o esaurimento opzioni
    4. Preserva l'orientamento originale dei dati (righe/colonne)

    Supporta due tipologie di dati:
    - **Dati statici** (info): strumenti finanziari con attributi (es. ISIN, nome, settore)
    - **Time series**: dati storici con DatetimeIndex (es. prezzi, volumi)

    Formato dati atteso:
    ----------------------
    INFO (dati statici):
        - Righe: strumenti finanziari (identificati da instrument.id)
        - Colonne: campi/attributi (es. 'PRICE', 'VOLUME', 'SECTOR')

    TIME SERIES (dati storici):
        - Righe: date (DatetimeIndex obbligatorio)
        - Colonne: campi/attributi (es. 'CLOSE', 'VOLUME')

    Esempio d'uso - Dati statici:
    ------------------------------
    >>> from bshdata.core.instruments.instruments import StockInstrument
    >>> from bshdata.client import BSHDataClient
    >>> from interface.api.info_data_api import InfoDataAPI
    >>> instruments = [StockInstrument('AAPL'), StockInstrument('MSFT')]
    >>> result = pd.DataFrame({
    ...     'PRICE': [150.0, None],
    ...     'VOLUME': [1000, 2000]
    ... }, index=['AAPL', 'MSFT'])
    >>>
    >>> fallbacks = [
    ...     {'source': 'bloomberg'},  # Prova Bloomberg
    ...     {'source': 'reuters'}     # Poi prova Reuters
    ... ]
    >>> private_dispatch_func = InfoDataAPI(BSHDataClient())._dispatch
    >>> complete_result = RetryManager.retry_info(
    ...     dispatch=private_dispatch_func,
    ...     result=result,
    ...     params={'instruments': instruments, 'fields': ['PRICE', 'VOLUME']},
    ...     fallbacks=fallbacks
    ... )

    Esempio d'uso - Time series:
    -----------------------------
    >>> from interface.api.market_api import MarketDataAPI
    >>> result = pd.DataFrame({
    ...     'CLOSE': [100.0, None, 102.0],
    ...     'VOLUME': [1000, 2000, None]
    ... }, index=pd.date_range('2024-01-01', periods=3))
    >>>
    >>> fallbacks = [
    ...     {'frequency': 'daily'},
    ...     {'frequency': 'intraday'}
    ... ]
    >>> private_dispatch_func = MarketDataAPI(BSHDataClient())._dispatch
    >>> complete_result = RetryManager.retry_time_series(
    ...     dispatch=private_dispatch_func,
    ...     result=result,
    ...     params={'fields': ['MID', 'BID'], 'start_date': '2024-01-01', 'end_date': '2024-01-03'},
    ...     fallbacks=fallbacks
    ... )

    Caratteristiche chiave:
    -----------------------
    - **Case-insensitive**: Gestisce automaticamente maiuscole/minuscole nei nomi campi
    - **Ottimizzazione richieste**: Richiede solo dati mancanti ad ogni iterazione
    - **Preservazione orientamento**: Ripristina l'orientamento originale del DataFrame
    - **Validazione robusta**: Converte Series→DataFrame, valida DatetimeIndex per time series
    - **Immutabilità parametri**: Non modifica i parametri originali passati dal caller
    - **Early exit**: Termina appena tutti i dati sono completi

    Note implementative:
    --------------------
    - I metodi `deep_update_*` usano `fillna()` per sostituire SOLO i valori NaN
    - La trasposizione è gestita automaticamente per garantire fields sulle colonne
    - I fallback sono provati in ordine sequenziale fino al primo successo completo
    - Il logging traccia tutte le operazioni principali per debug e monitoring
    - Parametri lista (es. overrides) sono filtrati in parallelo con instruments
    """

    # -------------------------
    # Utils
    # -------------------------

    @staticmethod
    def is_empty(value):
        """Verifica se un valore è considerato vuoto."""
        return (
                value is None
                or value == ""
                or value == []
                or value == {}
                or value == ()
                or (isinstance(value, float) and math.isnan(value))
        )

    @staticmethod
    def as_list(param):
        """Converte un parametro in lista se non lo è già."""
        return param if isinstance(param, list) else [param]

    @staticmethod
    def normalize_key(key: str) -> str:
        """Normalizza una chiave per confronti case-insensitive."""
        return key.upper()

    @staticmethod
    def get_fields_with_missing(result: pd.DataFrame) -> list:
        """
        Identifica colonne con almeno un valore mancante.

        Args:
            result: DataFrame da analizzare

        Returns:
            Lista di nomi colonne con valori NaN
        """
        return result.columns[result.isna().any(axis=0)].tolist()

    @staticmethod
    def get_rows_with_missing(result: pd.DataFrame) -> list:
        """
        Identifica righe (index) con almeno un valore mancante.

        Args:
            result: DataFrame da analizzare

        Returns:
            Lista di indici di righe con valori NaN
        """
        return result.index[result.isna().any(axis=1)].tolist()

    @staticmethod
    def filter_parallel_lists(keep_ids: List, all_instruments: List, params: Dict) -> Dict:
        """
        Filtra parametri che sono liste parallele agli strumenti.

        Mantiene solo gli elementi corrispondenti agli strumenti da mantenere,
        preservando l'ordine e l'allineamento tra le liste.

        Args:
            keep_ids: Lista di instrument.id da mantenere
            all_instruments: Lista completa di strumenti originali
            params: Dizionario parametri che può contenere liste parallele

        Returns:
            Dizionario con liste filtrate
        """
        # Crea mapping indice -> instrument.id
        id_to_idx = {inst.id: idx for idx, inst in enumerate(all_instruments)}

        # Trova gli indici da mantenere
        keep_indices = [id_to_idx[inst_id] for inst_id in keep_ids if inst_id in id_to_idx]

        # Filtra tutte le liste nei params che hanno lunghezza uguale a instruments
        filtered_params = params.copy()
        n_instruments = len(all_instruments)

        for key, value in params.items():
            # Salta 'instruments' che viene gestito separatamente
            if key == 'instruments':
                continue

            # Se è una lista con stessa lunghezza di instruments, filtrala
            if isinstance(value, list) and len(value) == n_instruments:
                filtered_params[key] = [value[idx] for idx in keep_indices]
                logger.debug(f"Filtrato parametro '{key}': {len(value)} → {len(filtered_params[key])} elementi")

        return filtered_params

    # -------------------------
    # Merge functions
    # -------------------------

    @classmethod
    def deep_update_info_results(cls, result: pd.DataFrame, new_result: pd.DataFrame) -> pd.DataFrame:
        """
        Merge per dati statici: sostituisce SOLO i valori NaN.

        Args:
            result: DataFrame con strumenti sull'indice, fields sulle colonne
            new_result: DataFrame con nuovi dati da integrare

        Returns:
            DataFrame aggiornato
        """
        # Converti Series in DataFrame se necessario
        if isinstance(new_result, pd.Series):
            new_result = new_result.to_frame()

        # Allinea indici e colonne (gestisce strumenti e campi non coincidenti)
        aligned_new = new_result.reindex_like(result)

        # Conta valori sostituiti per logging
        replaced_count = (result.isna() & aligned_new.notna()).sum().sum()
        if replaced_count > 0:
            logger.debug(f"deep_update_info_results: sostituiti {replaced_count} valori NaN")

        # Sostituisci solo i NaN
        result = result.fillna(aligned_new)

        return result

    @classmethod
    def deep_update_time_series(cls, result: pd.DataFrame, new_result: pd.DataFrame) -> pd.DataFrame:
        """
        Merge per time series: sostituisce SOLO i valori NaN.

        Args:
            result: DataFrame con DatetimeIndex, fields sulle colonne
            new_result: DataFrame con nuovi dati da integrare

        Returns:
            DataFrame aggiornato
        """
        # Converti Series in DataFrame se necessario
        if isinstance(new_result, pd.Series):
            new_result = new_result.to_frame()

        # Allinea indici e colonne
        aligned_new = new_result.reindex_like(result)

        # Sostituisci solo dove result è NaN E new_result ha valore
        mask = result.isna() & aligned_new.notna()
        replaced_count = mask.sum().sum()

        if replaced_count > 0:
            logger.debug(f"deep_update_time_series: sostituiti {replaced_count} valori NaN")

        result = result.mask(mask, aligned_new)

        return result

    # -------------------------
    # Validation & Normalization
    # -------------------------

    @classmethod
    def _validate_and_normalize_dataframe(cls, result: Union[pd.Series, pd.DataFrame]) -> pd.DataFrame:
        """
        Converte Series in DataFrame e valida il tipo.

        Args:
            result: Series o DataFrame da validare

        Returns:
            DataFrame validato

        Raises:
            TypeError: se result non è Series o DataFrame
        """
        if isinstance(result, pd.Series):
            logger.debug("Conversione Series → DataFrame")
            result = result.to_frame()

        if not isinstance(result, pd.DataFrame):
            logger.error(f"Tipo non valido: {type(result)}")
            raise TypeError(f"Expected pandas Series or DataFrame, got {type(result)}")

        return result

    @classmethod
    def _ensure_fields_on_columns(cls, result: pd.DataFrame, fields: List[str]) -> tuple[pd.DataFrame, bool]:
        """
        Assicura che i fields siano sulle colonne, trasponendo se necessario.

        Args:
            result: DataFrame da verificare
            fields: Lista di fields attesi

        Returns:
            Tuple (DataFrame orientato correttamente, flag_trasposizione)
        """
        # Normalizza i nomi per confronto case-insensitive
        result_cols_upper = {cls.normalize_key(col) for col in result.columns}
        fields_upper = {cls.normalize_key(f) for f in fields}

        # Verifica se i fields sono già sulle colonne
        if fields_upper.issubset(result_cols_upper):
            logger.debug("Orientamento corretto: fields già sulle colonne")
            return result, False

        # Trasponi
        logger.debug("Trasposizione DataFrame: fields non sulle colonne")
        result = result.T
        return result, True

    # -------------------------
    # MAIN ENTRYPOINT – INFO
    # -------------------------

    @classmethod
    def retry_info(cls,
                   dispatch: Callable,
                   result: Union[pd.Series, pd.DataFrame],
                   params: Dict,
                   fallbacks: List[Dict]) -> pd.DataFrame:
        """
        Imputazione per dati statici con retry su fallback.

        Args:
            dispatch: Funzione da chiamare per ottenere nuovi dati
            result: DataFrame o Series con dati iniziali (strumenti x fields)
            params: Parametri per dispatch (instruments, fields, etc.)
            fallbacks: Lista di dict con parametri alternativi da provare

        Returns:
            DataFrame con dati imputati
        """
        logger.info(f"retry_info: inizio con {len(fallbacks)} fallback configurati")

        # Non modificare params originale
        working_params = copy.deepcopy(params)

        # Validazione e normalizzazione
        result = cls._validate_and_normalize_dataframe(result)
        logger.debug(f"DataFrame shape: {result.shape}")

        # Assicurati che fields siano sulle colonne
        fields_list = cls.as_list(working_params["fields"])
        result, transposed = cls._ensure_fields_on_columns(result, fields_list)

        # Salva riferimento agli strumenti originali per filtraggio liste parallele
        original_instruments = working_params["instruments"]
        inst_dict = {inst.id: inst for inst in original_instruments}

        # 1) Identifica campi con valori mancanti
        fields_with_missing = cls.get_fields_with_missing(result)
        fields_upper_map = {cls.normalize_key(f): f for f in fields_list}

        working_params["fields"] = [
            fields_upper_map[cls.normalize_key(col)]
            for col in fields_with_missing
            if cls.normalize_key(col) in fields_upper_map
        ]

        # 2) Identifica strumenti con valori mancanti
        missing_instruments = cls.get_rows_with_missing(result)

        logger.info(f"Dati mancanti: {len(missing_instruments)} strumenti, {len(working_params['fields'])} campi")

        # Early exit se tutto è completo
        if not missing_instruments or not working_params["fields"]:
            logger.info("Nessun dato mancante: early exit")
            return result.T if transposed else result

        # Prepara oggetti strumenti mancanti
        inst_missing_objs = [inst_dict[x] for x in missing_instruments]

        for idx, fb in enumerate(fallbacks):
            param_name, param_value = next(iter(fb.items()))
            logger.info(f"Fallback {idx + 1}/{len(fallbacks)}: {param_name}={param_value}")
            fb_params = working_params.copy()
            old_param = working_params[param_name]
            if isinstance(old_param, list):
                if not isinstance(param_value, list):
                    param_value = normalize_list(param_value, len(old_param))
            fb_params[param_name] = param_value

            fb_params["instruments"] = inst_missing_objs

            fb_params = cls.filter_parallel_lists(
                keep_ids=missing_instruments,
                all_instruments=original_instruments,
                params=fb_params
            )
            # Dispatch e merge
            logger.debug(f"Dispatch con {len(inst_missing_objs)} strumenti, {len(fb_params['fields'])} campi")
            try:
                new_res = dispatch(**fb_params)
                new_res = cls._validate_and_normalize_dataframe(new_res)
            except Exception as e:
                logger.warning(f"cannot retry with {fb_params}", exc_info=e)
                continue

            # Assicura stesso orientamento di result
            if transposed:
                new_res, _ = cls._ensure_fields_on_columns(new_res, working_params["fields"])

            result = cls.deep_update_info_results(result, new_res)

            # Ricalcola campi con valori mancanti
            working_params["fields"] = [
                fields_upper_map[cls.normalize_key(col)]
                for col in cls.get_fields_with_missing(result)
                if cls.normalize_key(col) in fields_upper_map
            ]

            # Ricalcola strumenti mancanti
            missing_instruments = cls.get_rows_with_missing(result)

            logger.info(f"Dopo fallback {idx + 1}: {len(missing_instruments)} strumenti mancanti, "
                        f"{len(working_params['fields'])} campi mancanti")

            # Exit se completo
            if not missing_instruments or not working_params["fields"]:
                logger.info(f"Dati completi dopo fallback {idx + 1}: early exit")
                break

            inst_missing_objs = [inst_dict[x] for x in missing_instruments]

        # Ripristina orientamento originale
        final_result = result.T if transposed else result
        remaining_nans = final_result.isna().sum().sum()
        logger.info(f"retry_info completato: {remaining_nans} valori NaN rimanenti")

        return final_result

    # -------------------------
    # MAIN ENTRYPOINT – TIME SERIES
    # -------------------------

    @classmethod
    def retry_time_series(cls,
                          dispatch: Callable,
                          result: Union[pd.Series, pd.DataFrame],
                          params: Dict,
                          fallbacks: List[Dict]) -> pd.DataFrame:
        """
        Imputazione per time series con retry su fallback.

        Args:
            dispatch: Funzione da chiamare per ottenere nuovi dati
            result: DataFrame o Series con DatetimeIndex (date x fields)
            params: Parametri per dispatch (fields, start_date, end_date, etc.)
            fallbacks: Lista di dict con parametri alternativi da provare

        Returns:
            DataFrame con dati imputati

        Raises:
            ValueError: se result non ha DatetimeIndex
        """
        logger.info(f"retry_time_series: inizio con {len(fallbacks)} fallback configurati")

        # Non modificare params originale
        working_params = copy.deepcopy(params)

        # Validazione e normalizzazione
        result = cls._validate_and_normalize_dataframe(result)
        logger.debug(f"DataFrame shape: {result.shape}")

        # Verifica DatetimeIndex
        if not isinstance(result.index, pd.DatetimeIndex):
            logger.error("result non ha DatetimeIndex")
            raise ValueError("result deve avere un DatetimeIndex")

        # Assicurati che fields siano sulle colonne
        fields_list = cls.as_list(working_params["fields"])
        result, transposed = cls._ensure_fields_on_columns(result, fields_list)

        # Dopo trasposizione, verifica di nuovo DatetimeIndex
        if transposed and not isinstance(result.index, pd.DatetimeIndex):
            logger.error("Dopo trasposizione, result non ha DatetimeIndex")
            raise ValueError("Dopo trasposizione, result non ha un DatetimeIndex")

        # 1) Identifica campi con valori mancanti
        fields_upper_map = {cls.normalize_key(f): f for f in fields_list}

        working_params["fields"] = [
            fields_upper_map[cls.normalize_key(col)]
            for col in cls.get_fields_with_missing(result)
            if cls.normalize_key(col) in fields_upper_map
        ]

        # 2) Identifica date con valori mancanti
        dates_with_missing = cls.get_rows_with_missing(result)

        logger.info(f"Dati mancanti: {len(dates_with_missing)} date, {len(working_params['fields'])} campi")

        # Early exit se tutto è completo
        if not dates_with_missing or not working_params["fields"]:
            logger.info("Nessun dato mancante: early exit")
            return result.T if transposed else result

        # Ottimizza range date
        if dates_with_missing and "start_date" in working_params and "end_date" in working_params:
            working_params["start_date"] = min(dates_with_missing)
            working_params["end_date"] = max(dates_with_missing)
            logger.debug(f"Range date ottimizzato: {working_params['start_date']} - {working_params['end_date']}")

        # 3) Itera sui fallback
        for idx, fb in enumerate(fallbacks):
            param_name, param_value = next(iter(fb.items()))
            logger.info(f"Fallback {idx + 1}/{len(fallbacks)}: {param_name}={param_value}")

            # Prepara parametri per questo fallback
            fb_params = working_params.copy()
            fb_params[param_name] = param_value

            # Dispatch e merge
            logger.debug(f"Dispatch con {len(dates_with_missing)} date, {len(fb_params['fields'])} campi")
            new_res = dispatch(**fb_params)
            new_res = cls._validate_and_normalize_dataframe(new_res)

            # Assicura stesso orientamento di result
            if transposed:
                new_res, _ = cls._ensure_fields_on_columns(new_res, working_params["fields"])

            result = cls.deep_update_time_series(result, new_res)

            # Ricalcola campi con valori mancanti
            working_params["fields"] = [
                fields_upper_map[cls.normalize_key(col)]
                for col in cls.get_fields_with_missing(result)
                if cls.normalize_key(col) in fields_upper_map
            ]

            # Ricalcola date con valori mancanti
            dates_with_missing = cls.get_rows_with_missing(result)

            logger.info(f"Dopo fallback {idx + 1}: {len(dates_with_missing)} date mancanti, "
                        f"{len(working_params['fields'])} campi mancanti")

            # Exit se completo
            if not dates_with_missing or not working_params["fields"]:
                logger.info(f"Dati completi dopo fallback {idx + 1}: early exit")
                break

            # Aggiorna range date per prossimo fallback
            if dates_with_missing and "start_date" in working_params and "end_date" in working_params:
                working_params["start_date"] = min(dates_with_missing)
                working_params["end_date"] = max(dates_with_missing)

        # Ripristina orientamento originale
        final_result = result.T if transposed else result
        remaining_nans = final_result.isna().sum().sum()
        logger.info(f"retry_time_series completato: {remaining_nans} valori NaN rimanenti")

        return final_result