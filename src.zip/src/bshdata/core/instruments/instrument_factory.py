# bshdata/core/instruments/factory/instrument_factory.py

import logging
from typing import Optional, Type
from bshdata.core.enums.instrument_types import InstrumentType

from bshdata.core.instruments.classifier.instrument_classifier import InstrumentClassifier
from bshdata.core.instruments.instruments import (
    Instrument, InstrumentRegistry,
    FutureInstrument, CDXIndexInstrument, EtfInstrument, SwapInstrument, IndexInstrument, RatesIndexInstrument
)
from bshdata.core.utils.singleton import Singleton

logger = logging.getLogger(__name__)


class InstrumentFactory(Singleton):
    """
    Central factory for building Instrument objects.

    Delegates metadata lookup to InstrumentClassifier, handles:
        - identifier resolution
        - type inference
        - routing to builder methods
    """

    def __init__(self, client=None, warmup: bool = True):
        self.client = client
        self.providers = getattr(client, "providers", {}) if client else {}

        oracle_provider = self.providers.get("oracle")
        self._classifier = InstrumentClassifier(
            oracle_provider.query if oracle_provider else None
        )

        if warmup and oracle_provider:
            self._classifier.warmup()

    # ==================================================================
    # PUBLIC API: create()
    # ==================================================================
    def create(
        self,
        id: Optional[str] = None,
        type: InstrumentType | str | None = None,
        ticker: Optional[str] = None,
        isin: Optional[str] = None,
        currency: Optional[str] = None,
        autocomplete: bool = False,
        **kwargs,
    ) -> Instrument:

        # --- resolve ID / ISIN / ticker ---
        isin, ticker, id = self._resolve_identifiers(id, isin, ticker, autocomplete)

        # --- infer type ---
        if type is None:
            type = self._classifier.infer_type(isin or ticker or id)
        if isinstance(type, str):
            type = InstrumentType.from_str(type)

        # --- dispatch ---
        match type:
            case InstrumentType.FUTURE:
                return self._build_future(id, isin, ticker, currency, autocomplete, **kwargs)

            case InstrumentType.ETP:
                return self._build_etp(id, isin, ticker, currency, autocomplete, **kwargs)

            case InstrumentType.CURRENCYPAIR:
                return self._build_currency_pair(id)

            case InstrumentType.SWAP:
                return self._build_swap(id, autocomplete, **kwargs)

            case InstrumentType.STOCK:
                return self._build_stock(id, isin, ticker, currency, autocomplete, **kwargs)

            case InstrumentType.CDXINDEX:
                return self._build_cdx(id, ticker, autocomplete, **kwargs)

            case InstrumentType.INDEX:
                return self._build_index(id, ticker, autocomplete, currency=currency,  **kwargs)

            case _:
                cls: Type[Instrument] = InstrumentRegistry.get_class(type)
                return cls(type=type, ticker=ticker, isin=isin, id=id, currency=currency)

    # ==================================================================
    # BUILDERS
    # ==================================================================

    # ---------- FUTURE ----------
    def _build_future(self, id_, isin, ticker, currency, autocomplete, **kwargs) -> FutureInstrument:
        if autocomplete:
            meta = self._classifier.get_future_metadata(id_)
            kwargs.update({k: v for k, v in meta.items() if v is not None})

        fut = FutureInstrument(
            isin=isin,
            id=id_,
            ticker=ticker,
            currency=kwargs.pop("future_currency", currency),
            is_active_form=kwargs.get("is_active_form"),
            root=kwargs.get("root"),
            future_underlying=kwargs.get("future_underlying"),
            suffix=kwargs.get("suffix"),
            timescale_root=kwargs.get("timescale_root"),
        )

        underlying = fut.future_underlying or kwargs.get("future_underlying")
        return fut.set_future_underlying(underlying)

    # ---------- ETP ----------
    def _build_etp(self, id_, isin, ticker, currency, autocomplete, **kwargs) -> EtfInstrument:

        underlying = kwargs.get("etf_underlying")
        mkt = kwargs.get("market")

        if autocomplete:
            if not ticker and not isin:
                if id_ in self._classifier.etp.tickers:
                    ticker = id_
            isin, ticker = self._classifier.auto_complete(isin, ticker, InstrumentType.ETP)
            currency = currency or (self._classifier.get_ccy(isin, mkt, InstrumentType.ETP) if mkt else None)
            underlying = underlying or self._classifier.etp.get_undelying_type(isin)

        cls: Type[Instrument] = InstrumentRegistry.get_class(InstrumentType.ETP)
        return cls(type=InstrumentType.ETP, isin=isin, id=id_, ticker=ticker, currency=currency, underlying_type=underlying)

    # ---------- FX ----------
    def _build_currency_pair(self, id_) -> Instrument:
        cls = InstrumentRegistry.get_class(InstrumentType.CURRENCYPAIR)
        return cls(type=InstrumentType.CURRENCYPAIR, id=id_)

    # ---------- CDX ----------
    def _build_cdx(self, id, ticker, autocomplete, **kwargs) -> CDXIndexInstrument:
        cls = InstrumentRegistry.get_class(InstrumentType.CDXINDEX)
        uid = id.upper()

        # ------------------------------
        # FIX: ticker fallback = id
        # ------------------------------
        if ticker is None:
            ticker = id

        ticker_root = kwargs.pop("ticker_root", None)

        if not ticker_root:
            if len(uid) == 8 and any(uid.endswith(str(s)) for s in range(35, 50)):
                ticker_root = uid[:-2]
            else:
                ticker_root = ticker.upper()

        # autocomplete metadata
        if autocomplete:
            for f in ("CURRENCY", "INDEX_NAME", "TENOR", "SERIES"):
                key = f.lower()
                kwargs[key] = kwargs.get(key) or self._classifier.get_cdx_field(ticker_root, f)

            if not self._classifier.cds.matches(ticker_root):
                logger.warning(f"{ticker_root} is not a recognized CDS root.")

        return cls(type=InstrumentType.CDXINDEX, ticker=id, ticker_root=ticker_root, **kwargs)

    # ---------- STOCK ----------
    def _build_stock(self, id, isin, ticker, currency, autocomplete, **kwargs):
        cls = InstrumentRegistry.get_class(InstrumentType.STOCK)
        if autocomplete:
            isin, ticker = self._classifier.auto_complete(isin, ticker, InstrumentType.STOCK)
            mkt = kwargs.get("market")
            currency = currency or (self._classifier.get_ccy(isin,
                                                             market=mkt,
                                                             instrument_type=InstrumentType.STOCK) if mkt else None)

        return cls(
            type=InstrumentType.STOCK,
            id=id,
            currency=currency,
            ticker=ticker,
            isin=isin,
            **kwargs
        )

    # ---------- SWAP ----------
    def _build_swap(self, id, autocomplete, **kwargs) -> Instrument:
        cls = InstrumentRegistry.get_class(InstrumentType.SWAP)

        tenor = (
            kwargs.pop("tenor", None)
            or (self._classifier.swap.extract_tenor(id) if autocomplete else None)
        )

        ticker = (
            kwargs.pop("ticker", None)
            or (id if (self._classifier.swap.matches(id) and autocomplete) else None)
        )

        return cls(id=id, ticker=ticker, tenor=tenor)

    def _build_index(self, id, ticker, autocomplete, **kwargs) -> Instrument:
        """
        Costruisce un Rates Index Instrument (EURIBOR, ESTR, SOFR...)
        usando ID / TICKER / FAMILY / TENOR + completamento automatico.
        """
        family = kwargs.get("family")
        tenor = kwargs.get("tenor")
        ccy = kwargs.get("currency")
        if not ticker:
            ticker = self._classifier.index.get_ticker_by_id(id, tenor)

        if autocomplete:
            if not ticker and family:
                if not tenor:
                    logger.warning(f"Index specified only as family '{family}'. TENOR missing → using default 1D.")
                    tenor = "1D"

            if not family and ticker:
                family = self._classifier.index.get_family(ticker)
            if not tenor:
                tenor = self._classifier.index.get_tenor(ticker, family)
            ccy = ccy or self._classifier.index.get_currency_from_family(family)
        row = self._classifier.index.lookup_by_ticker(ticker) or {}

        # I kwargs devono OVERRIDE il dataset
        comp = kwargs.get("compounding", row.get("COMPOUNDING"))
        dcount = kwargs.get("day_count", row.get("DAY_COUNT"))
        bdc = kwargs.get("business_day_convention", row.get("BUSINESS_DAY_CONVENTION"))
        eom = kwargs.get("eom", row.get("EOM"))
        is_rate_index = any((comp, dcount, bdc, eom))
        if is_rate_index:
            return RatesIndexInstrument(
            id=id,
            ticker=ticker,
            tenor=tenor,
            compounding=comp,
            currency=ccy,
            day_count=dcount,
            business_day_convention=bdc,
            eom=eom,
            family=family,
        )
        cls: Type[Instrument] = InstrumentRegistry.get_class(InstrumentType.INDEX)
        return cls(
            id=id,
            name=ticker,
            tenor=tenor,
            compounding=comp,
            currency=ccy,
            day_count=dcount,
            business_day_convention=bdc,
            eom=eom,
            family=family,
        )

    # ==================================================================
    # INTERNAL HELPERS
    # ==================================================================
    def _resolve_identifiers(self, id_, isin, ticker, autocomplete):
        # ID is ISIN
        if id_ and self._classifier.etp.ISIN_RE.match(id_):
            isin = isin or id_

        if not id_:
            id_ = isin or ticker

        return isin, ticker, id_

    # ----------------------------------------------------------------------
    # Convenience wrappers
    # ----------------------------------------------------------------------
    def as_isin(self, *args, **kwargs) -> str:
        return self._classifier.etp.as_isin(*args, **kwargs)

    def as_ticker(self, *args, **kwargs) -> str:
        return self._classifier.etp.as_ticker(*args, **kwargs)
