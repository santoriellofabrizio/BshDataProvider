from dataclasses import dataclass
from typing import Optional, Type, Dict, TypeVar, Union
import logging

from bshdata.core.enums.currencies import Currency
from bshdata.core.enums.instrument_types import InstrumentType
from bshdata.core.enums.markets import Market

logger = logging.getLogger(__name__)
T = TypeVar("T", bound="Instrument")


# ============================================================
# BASE
# ============================================================
@dataclass
class Instrument:
    ticker: Optional[str] = None
    isin: Optional[str] = None
    id: Optional[str] = None
    currency: Optional[Currency | str] = None
    type: Optional[InstrumentType] = None
    market: Optional[str] = None

    def __post_init__(self):
        if not any([self.ticker, self.isin, self.id]):
            raise ValueError("Instrument requires at least one between ticker, isin or id.")

        if self.id is None:
            self.id = self.isin or self.ticker

        # Normalizza type e currency
        if isinstance(self.type, str):
            self.type = InstrumentType.from_str(self.type)

        if self.type != InstrumentType.CURRENCYPAIR:
            if isinstance(self.currency, str):
                self.currency = Currency.from_str(self.currency)
            self.currency = self.currency or Currency.EUR

    # ============================================================
    # 🔹 AUTOPROMOTION METHOD
    # ============================================================
    def set_type(self: T, new_type: InstrumentType | str) -> T:
        """
        Imposta il tipo e promuove automaticamente l'istanza
        alla sottoclasse corretta registrata nel registry.
        """
        if isinstance(new_type, str):
            new_type = InstrumentType.from_str(new_type)

        self.type = new_type
        subclass = InstrumentRegistry.get_class(new_type)

        if not isinstance(self, subclass):
            promoted = subclass.__new__(subclass)
            promoted.__dict__.update(self.__dict__)
            promoted.__post_init__()  # esegue validazioni della sottoclasse
            logger.debug(f"Promoted Instrument → {subclass.__name__} (type={new_type})")
            return promoted  # restituisce la sottoclasse coerente

        return self

    def __repr__(self):
        return f"{self.__class__.__name__}(id={self.id}, type={self.type}, currency={self.currency})"


# ============================================================
# ETF
# ============================================================
@dataclass
class EtfInstrument(Instrument):

    underlying_type: Optional[str] = None

    def __post_init__(self):
        self.type = InstrumentType.ETP
        if self.underlying_type is not None:
            if self.underlying_type.upper() not in ["EQUITY", "FIXED INCOME"]:
                raise ValueError("Instrument requires underlying type to EQUITY or FIXED INCOME")
            self.underlying_type = self.underlying_type.upper()

        super().__post_init__()


class FxForwardInstrument(Instrument):
    def __post_init__(self):
        self.type = InstrumentType.FXFWD


# ============================================================
# STOCK
# ============================================================
@dataclass
class StockInstrument(Instrument):
    def __post_init__(self):
        self.type = InstrumentType.STOCK
        super().__post_init__()


# ============================================================
# CURRENCYPAIR
# ============================================================
@dataclass
class CurrencyPairInstrument(Instrument):
    ref_currency: Optional[Currency] = None
    ref_currency_multiplier: Optional[float] = None

    def __post_init__(self):
        self.type = InstrumentType.CURRENCYPAIR
        self.currency = None
        if self.ref_currency and self.ref_currency_multiplier is None:
            raise ValueError(
                f"Derived currency {self.id} is derived from {self.ref_currency} → missing multiplier"
            )
        super().__post_init__()


# ============================================================
# FUTURE BASE
# ============================================================
@dataclass
class FutureInstrument(Instrument):
    is_active_form: bool = True
    root: Optional[str] = None
    future_underlying: Optional[str] = None
    suffix: Optional[str] = None
    timescale_root: Optional[str] = None

    def __post_init__(self):
        self.type = InstrumentType.FUTURE
        self.suffix = self.suffix.upper() if self.suffix else None
        if self.suffix not in ["INDEX", "COMDTY"]:
            raise ValueError("Future instrument requires a suffix like INDEX or COMDTY")
        super().__post_init__()

    def set_future_underlying(self: T, value: str):
        if not value:
            raise ValueError("future_underlying cannot be empty")

        value_upper = value.strip().upper()
        self.future_underlying = value_upper

        subclass = {
            "EQUITY": EquityFuture,
            "FIXED INCOME": FixedIncomeFuture,
        }.get(value_upper, FutureInstrument)

        if not isinstance(self, subclass):
            promoted = subclass.__new__(subclass)
            promoted.__dict__.update(self.__dict__)
            promoted.__post_init__()
            logger.debug(f"Promoted FutureInstrument → {subclass.__name__} (underlying={value_upper})")
            return promoted

        return self


# ============================================================
# FUTURE SUBTYPES
# ============================================================
@dataclass
class FixedIncomeFuture(FutureInstrument):
    def __post_init__(self):
        self.future_underlying = "FIXEDINCOME"
        super().__post_init__()


@dataclass
class EquityFuture(FutureInstrument):
    def __post_init__(self):
        self.future_underlying = "EQUITY"
        super().__post_init__()


@dataclass
class SwapInstrument(Instrument):
    tenor: Optional[str] = None
    swap_type = Optional[str]

    def __post_init__(self):
        super().__post_init__()
        self.type = InstrumentType.SWAP


@dataclass
class CDXIndexInstrument(Instrument):
    ticker_root: Optional[str] = None
    index_name: Optional[str] = None
    series: Optional[str] = None
    tenor: Optional[Union[str, int]] = None
    is_active_form: Optional[bool] = True

    def __post_init__(self):
        super().__post_init__()
        self.type = InstrumentType.CDXINDEX
        if self.tenor:
            if isinstance(self.tenor, int):
                self.tenor = f"{self.tenor}y"


@dataclass
class IndexInstrument(Instrument):
    name: Optional[str] = None

    def __post_init__(self):
        super().__post_init__()
        self.type = InstrumentType.INDEX


@dataclass
class RatesIndexInstrument(IndexInstrument):

    tenor: Optional[str] = None
    family: Optional[str] = None
    compounding: Optional[str] = None
    currency: Optional[str] = None
    day_count: Optional[str] = None
    business_day_convention: Optional[str] = None
    eom: Optional[bool] = None


# ============================================================
# REGISTRY
# ============================================================
class InstrumentRegistry:
    _registry: Dict[InstrumentType, Type[Instrument]] = {}

    @classmethod
    def register(cls, instrument_type: InstrumentType, klass: Type[Instrument]):
        cls._registry[instrument_type] = klass

    @classmethod
    def get_class(cls, instrument_type: InstrumentType) -> Type[Instrument]:
        return cls._registry.get(instrument_type, Instrument)


# Registrazione automatica
InstrumentRegistry.register(InstrumentType.ETP, EtfInstrument)
InstrumentRegistry.register(InstrumentType.STOCK, StockInstrument)
InstrumentRegistry.register(InstrumentType.CURRENCYPAIR, CurrencyPairInstrument)
InstrumentRegistry.register(InstrumentType.FUTURE, FutureInstrument)
InstrumentRegistry.register(InstrumentType.SWAP, SwapInstrument)
InstrumentRegistry.register(InstrumentType.CDXINDEX, CDXIndexInstrument)
InstrumentRegistry.register(InstrumentType.FXFWD, FxForwardInstrument)
InstrumentRegistry.register(InstrumentType.INDEX, IndexInstrument)