# future_classifier.py
import pandas as pd
from bshdata.core.utils.memory_provider import cache_bsh_data
from .base_classifier import BaseClassifier


class FutureClassifier(BaseClassifier):

    @cache_bsh_data
    def load(self):
        if self._rate_df is None:
            if not self.oracle:
                raise RuntimeError("FutureClassifier: manca QueryOracle")
            self._df = pd.DataFrame(self.oracle.get_futures_data())
        return self._df

    # ------------------------------------------------------------
    def matches(self, identifier: str) -> bool:
        df = self.load()
        idu = identifier.upper()

        cols = ["ISIN", "CONTRACT", "TICKER",
                "ACTIVE_ISIN", "ACTIVE_CONTRACT", "EXCH_SYMBOL"]

        # Direct match
        for _, row in df.iterrows():
            if any(idu == str(row.get(c, "")).upper() for c in cols):
                return True

        # EXCH_SYMBOL trimmed of numbers
        clean = idu
        for y in range(2020, 2035):
            clean = clean.replace(str(y), "")
        for m in range(1, 13):
            clean = clean.replace(str(m), "")

        return clean in df["EXCH_SYMBOL"].astype(str).str.upper().values

    # ------------------------------------------------------------
    def get_metadata(self, identifier: str):
        df = self.load()
        up = identifier.upper()

        clean = up
        for y in range(2020, 2035):
            clean = clean.replace(str(y), "")
        for m in range(1, 13):
            clean = clean.replace(str(m), "")

        cols = ["ACTIVE_ISIN", "ISIN", "CONTRACT",
                "ACTIVE_CONTRACT", "TICKER", "EXCH_SYMBOL"]

        row = df[df[cols].apply(lambda r: r.astype(str).str.upper().eq(clean).any(), axis=1)]
        if row.empty:
            return {}

        r = row.iloc[0]
        return {
            "root": r.get("TICKER_ROOT") or r.get("TICKER"),
            "future_underlying": r.get("UNDERLYING_TYPE"),
            "suffix": r.get("BBG_TYPE"),
            "is_active_form": up in str(r.get("ACTIVE_ISIN", "")) or up in str(r.get("ACTIVE_CONTRACT", "")),
            "timescale_root": r.get("EXCH_SYMBOL"),
            "future_currency": r.get("CURRENCY"),
        }

    def get_ccy(self, isin, market):
        raise NotImplementedError
