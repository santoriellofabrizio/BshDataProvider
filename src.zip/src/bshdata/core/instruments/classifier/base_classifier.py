# base_classifier.py
from typing import Optional

import pandas as pd

from bshdata.providers.oracle.query_oracle import QueryOracle


class BaseClassifier:
    def __init__(self, oracle: Optional[QueryOracle] = None):
        self.oracle = oracle
        self._rate_df = None  # Lazy-loaded dataframe

    def load(self) -> pd.DataFrame:
        raise NotImplementedError

    def matches(self, identifier: str) -> bool:
        return False
