# etp_classifier.py
import re
from typing import Optional

import pandas as pd

from bshdata.providers.oracle.query_oracle import QueryOracle
from .base_classifier import BaseClassifier


class ETPClassifier(BaseClassifier):

    ISIN_RE = re.compile(r"^[A-Z]{2}[A-Z0-9]{9}[0-9]$")

    def __init__(self, oracle: Optional[QueryOracle] = None):
        super().__init__(oracle)
        self._isins = None
        self._tickers = []

    def load(self):
        if self._rate_df is None:
            if not self.oracle:
                raise RuntimeError("ETPClassifier: manca QueryOracle")
            self._df = pd.DataFrame(self.oracle.get_etps_data())
            self._build_maps()
        return self._df

    # ------------------------------------------------------------
    def _build_maps(self):
        df = self._df

        self.isin_to_ticker = (
            df.dropna(subset=["ISIN", "TICKER"])
              .drop_duplicates(subset=["ISIN"])
              .set_index("ISIN")["TICKER"].astype(str)
              .to_dict()
        )

        self.ticker_to_isin = {v: k for k, v in self.isin_to_ticker.items()}

    # ------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------

    @property
    def tickers(self):
        if not self._tickers:
            self.load()
            self._tickers = self.ticker_to_isin.keys()
        return self._tickers

    @property
    def isins(self):
        if not self._isins:
            self.load()
            self._isins = self.isin_to_ticker.keys()
        return self._isins

    def matches(self, identifier: str) -> bool:
        self.load()
        return identifier in self.isins or identifier in self.tickers

    def as_ticker(self, isin: str):
        self.load()
        return self.isin_to_ticker.get(isin)

    def as_isin(self, ticker: str):
        self.load()
        return self.ticker_to_isin.get(ticker)

    def get_ccy(self, isin: str, market: str):
        self.load()
        result = self._df.loc[(self._df["ISIN"] == isin) & (self._df["EXCHANGE_CODE"] == market), "CURRENCY"]
        return result.iloc[0] if len(result) > 0 else None

    def get_undelying_type(self, id_):
        self.load()
        result = self._df.loc[(self._df["ISIN"] == id_), "UNDERLYING_TYPE"]
        return result.iloc[0] if len(result) > 0 else None