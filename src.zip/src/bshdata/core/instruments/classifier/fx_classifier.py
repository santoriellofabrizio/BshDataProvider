# fx_classifier.py
from bshdata.core.enums.currencies import Currency
from .base_classifier import BaseClassifier


class FXClassifier(BaseClassifier):

    def load(self):
        return None  # nessun dataset

    def matches(self, identifier: str) -> bool:
        s = identifier.replace(" ", "")
        return len(s) == 6 and Currency.exists(s[:3]) and Currency.exists(s[3:])
