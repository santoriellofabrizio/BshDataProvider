
from datetime import date, timedelta, datetime
from functools import lru_cache
import pandas as pd
import os


class HolidayManager:
    def __init__(self, config_path=None):
        if config_path is None:
            config_path = os.path.join(os.path.dirname(__file__), "holidays.yaml")

        from ruamel.yaml import YAML
        yaml = YAML(typ="safe")

        with open(config_path, "r", encoding="utf-8") as f:
            self.config = yaml.load(f) or {}

        if not isinstance(self.config, dict):
            raise ValueError(f"Invalid holidays.yaml format at {config_path}: expected mapping, got {type(self.config)}")


    @lru_cache(maxsize=None)
    def is_holiday(self, dt: date, market: str = "default") -> bool:
        """
        Returns True if the date is a weekend or holiday for the given market.
        """
        market_cfg = self.config["markets"].get(market, {})
        default_cfg = self.config["default"]

        # Check weekend
        if dt.strftime("%A") in default_cfg["weekends"]:
            return True

        # Check fixed holidays
        fixed_days = set(default_cfg.get("fixed", []))
        fixed_days.update(market_cfg.get("fixed", []))
        if dt.strftime("%m-%d") in fixed_days:
            return True

        return False

    def next_business_day(self, dt: date, market: str = "default") -> date:
        """Return the next business day after dt."""
        dt += timedelta(days=1)
        while self.is_holiday(dt, market):
            dt += timedelta(days=1)
        return dt

    def previous_business_day(self, dt: date, market: str = "default") -> date:
        """Return the last business day before dt."""
        dt -= timedelta(days=1)
        while self.is_holiday(dt, market):
            dt -= timedelta(days=1)
        return dt

    def get_business_days(self, start: date, end: date, market: str = "default") -> pd.DatetimeIndex:
        """Return all business days between start and end."""
        days = pd.date_range(start, end, freq="D")
        return days[~days.to_series().apply(lambda x: self.is_holiday(x.date(), market))]
